import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { GoogleGenAI, Type } from '@google/genai';
import { generateStructuredAnalysis } from './src/utils/fallbackAnalyzer.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 3000;

app.use(express.json({ limit: '10mb' }));

const getGeminiClient = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (
    !apiKey ||
    apiKey === 'MY_GEMINI_API_KEY' ||
    apiKey.startsWith('MY_') ||
    apiKey.trim().length < 10
  ) {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
};

const SYSTEM_INSTRUCTION = `You are the analytical engine behind "Critical Claim Checker", a web application dedicated to helping users carefully and respectfully examine claims that may be conspiracy theories, misinformation, unverified rumors, viral social media posts, or disputed accounts.

CORE PHILOSOPHY & NON-NEGOTIABLE PRINCIPLES:
1. Tone: Calm, neutral, respectful, intellectual, and completely non-judgmental. Do NOT insult, mock, lecture, or scold the user. Avoid patronizing words like "obviously", "foolish", "gullible", or "debunked once and for all".
2. Encourage careful thinking, intellectual humility, and evidence-based inquiry.
3. User boundary: Do not diagnose the user or make claims/assumptions about their personal psychology, motives, or character.
4. Urgent safety check: If the claim touches on violence, self-harm, medical treatment/quackery replacing critical care, or an active emergency, provide a clear, neutral safety notice in "safetyNotice" advising the user to consult qualified medical professionals, crisis resources, or emergency authorities. Otherwise, set "safetyNotice" to null or empty string.
5. In Section 2 (Evidence Checklist), address all 9 standard questions:
   - Who originally made the claim?
   - Is the source identifiable and credible?
   - Is there direct, verifiable evidence?
   - Have independent reliable sources corroborated it?
   - Do relevant subject-matter experts agree?
   - Are dates, locations, names, images, or statistics accurate?
   - Could simpler alternative explanations explain the evidence?
   - What evidence, if found, would weaken the claim?
   - What evidence, if found, would strengthen the claim?
   For each question, provide a neutral assessment, an honest status ("verified", "mixed", "unverified", "lacking", or "open"), and guidance.
6. In Section 3 (Reasoning Review), evaluate whether logical fallacies or cognitive heuristic traps appear, such as:
   - Confirmation bias
   - Cherry-picking evidence
   - Appeal to secrecy ("they are hiding it")
   - False cause (post hoc ergo propter hoc / confusing correlation with causation)
   - Appeal to authority without evidence
   - Overgeneralization
   - Motivated reasoning
   - Unfalsifiable claims
   CRITICAL: Explain each issue ONLY IF IT ACTUALLY APPEARS in the claim or common arguments for it. Do not invent fallacies if the claim does not exhibit them.
7. In Section 4 (What reliable sources indicate):
   Distinguish clearly between:
   - Well-supported facts (what is known with strong evidentiary backing)
   - Uncertain or disputed points (genuine nuances, unresolved questions, or data gaps)
   - Claims that lack credible supporting evidence (assertions made without rigorous substantiation)
8. In Section 5 (Better questions to ask):
   Provide exactly 5 neutral, open-minded questions that empower the user to independently investigate further.
9. In Section 6 (Balanced conclusion):
   The "label" MUST be EXACTLY one of these four strings:
   - "Well supported"
   - "Partly supported, important gaps remain"
   - "Not currently supported by credible evidence"
   - "Insufficient information to judge"
   Follow this with a 2–4 sentence balanced explanation. Never claim absolute certainty beyond the evidence.
10. In Section 7 (Recommended next steps):
    Provide 3 practical verification steps (e.g. checking primary peer-reviewed sources, consulting reputable archives, examining raw statistical databases, or consulting domain experts).`;

const analysisResponseSchema = {
  type: Type.OBJECT,
  properties: {
    summary: {
      type: Type.OBJECT,
      properties: {
        plainEnglishRestatement: {
          type: Type.STRING,
          description: "Restate the claim neutrally in 2-3 sentences without mockery or bias.",
        },
        centralFactualQuestion: {
          type: Type.STRING,
          description: "The core factual, empirical question at the heart of the claim.",
        },
        category: {
          type: Type.STRING,
          description: "Domain of the claim (e.g. Health & Medicine, History & Archaeology, Science & Astronomy, Politics & Governance, Viral Media).",
        },
        safetyNotice: {
          type: Type.STRING,
          description: "Advisory if medical, self-harm, violent, or emergency risk exists. Otherwise empty string.",
        },
      },
      required: ["plainEnglishRestatement", "centralFactualQuestion", "category"],
    },
    evidenceChecklist: {
      type: Type.ARRAY,
      description: "Evaluation for the 9 core critical thinking questions.",
      items: {
        type: Type.OBJECT,
        properties: {
          id: { type: Type.STRING },
          question: { type: Type.STRING },
          status: {
            type: Type.STRING,
            description: "Must be one of: verified, mixed, unverified, lacking, open",
          },
          statusText: {
            type: Type.STRING,
            description: "Short label like 'Identified', 'Mixed / Disputed', 'Lacking Direct Proof', 'Under Investigation', 'Plausible Alternative'",
          },
          assessment: {
            type: Type.STRING,
            description: "2-3 sentences providing objective, calm evaluation of this question.",
          },
          guidance: {
            type: Type.STRING,
            description: "Brief tip for what a critical thinker checks regarding this question.",
          },
        },
        required: ["id", "question", "status", "statusText", "assessment", "guidance"],
      },
    },
    reasoningReview: {
      type: Type.OBJECT,
      properties: {
        detectedPatterns: {
          type: Type.ARRAY,
          description: "Logical fallacies or heuristic pitfalls that specifically appear in this claim.",
          items: {
            type: Type.OBJECT,
            properties: {
              name: { type: Type.STRING },
              explanation: {
                type: Type.STRING,
                description: "Gentle, specific explanation of where and how this appears in the claim.",
              },
              constructiveAlternative: {
                type: Type.STRING,
                description: "How to examine this aspect with greater rigor or open-minded skepticism.",
              },
            },
            required: ["name", "explanation", "constructiveAlternative"],
          },
        },
        overallAssessment: {
          type: Type.STRING,
          description: "A calm 2-3 sentence overview of the claim's logical structure.",
        },
      },
      required: ["detectedPatterns", "overallAssessment"],
    },
    reliableSources: {
      type: Type.OBJECT,
      properties: {
        summaryOverview: {
          type: Type.STRING,
          description: "A synthesized overview of current scientific, journalistic, or historical consensus.",
        },
        wellSupportedFacts: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Facts supported by robust, verifiable documentation or broad scientific consensus.",
        },
        uncertainOrDisputedPoints: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Legitimate ambiguities, evolving research questions, or incomplete records.",
        },
        claimsLackingCredibleEvidence: {
          type: Type.ARRAY,
          items: { type: Type.STRING },
          description: "Assertions made in the claim that have no verifiable evidentiary basis.",
        },
      },
      required: ["summaryOverview", "wellSupportedFacts", "uncertainOrDisputedPoints", "claimsLackingCredibleEvidence"],
    },
    betterQuestions: {
      type: Type.ARRAY,
      description: "Exactly 5 neutral, productive questions for further inquiry.",
      items: {
        type: Type.OBJECT,
        properties: {
          question: { type: Type.STRING },
          purpose: {
            type: Type.STRING,
            description: "Why asking this specific question clarifies the truth.",
          },
        },
        required: ["question", "purpose"],
      },
    },
    conclusion: {
      type: Type.OBJECT,
      properties: {
        label: {
          type: Type.STRING,
          description: "Must be EXACTLY one of: 'Well supported', 'Partly supported, important gaps remain', 'Not currently supported by credible evidence', 'Insufficient information to judge'",
        },
        explanation: {
          type: Type.STRING,
          description: "2-4 sentence explanation. Never claim certainty beyond the evidence.",
        },
      },
      required: ["label", "explanation"],
    },
    recommendedNextSteps: {
      type: Type.ARRAY,
      description: "3 practical, constructive verification steps.",
      items: {
        type: Type.OBJECT,
        properties: {
          title: { type: Type.STRING },
          action: { type: Type.STRING },
          concreteTarget: {
            type: Type.STRING,
            description: "Suggested resource type (e.g. PubMed/Cochrane, National Archives, Primary peer-reviewed journals, Public FOIA repositories).",
          },
        },
        required: ["title", "action", "concreteTarget"],
      },
    },
  },
  required: [
    "summary",
    "evidenceChecklist",
    "reasoningReview",
    "reliableSources",
    "betterQuestions",
    "conclusion",
    "recommendedNextSteps",
  ],
};

app.post('/api/analyze-claim', async (req: Request, res: Response): Promise<void> => {
  try {
    const { claim } = req.body;
    if (!claim || typeof claim !== 'string' || claim.trim().length === 0) {
      res.status(400).json({ error: 'Please provide a claim, article excerpt, or link description to examine.' });
      return;
    }

    console.log('[Analyze Claim] Processing claim:', claim.slice(0, 60));
    const ai = getGeminiClient();
    console.log('[Analyze Claim] AI client available:', !!ai);
    let text: string | undefined = undefined;

    if (ai) {
      const userPrompt = `Please perform a thorough, neutral, and respectful critical examination of the following claim or text:

"""
${claim.trim()}
"""

Produce a comprehensive structured analysis addressing all 7 core sections. Ensure the tone is calm, analytical, and respectful without any condescension or diagnostic labeling.`;

      const candidateModels = ['gemini-3.8-flash'];

      for (const model of candidateModels) {
        try {
          const timeoutPromise = new Promise<never>((_, reject) =>
            setTimeout(() => reject(new Error('Model generation timed out')), 4500)
          );

          const genPromise = ai.models.generateContent({
            model,
            contents: userPrompt,
            config: {
              systemInstruction: SYSTEM_INSTRUCTION,
              responseMimeType: 'application/json',
              responseSchema: analysisResponseSchema,
            },
          });

          const response = await Promise.race([genPromise, timeoutPromise]);
          text = response.text;
          if (text) break;
        } catch (err: any) {
          console.warn(`[Analyze Claim] Attempt with ${model} failed/timed out:`, err?.message || err);
          // If auth or timeout failed, don't cascade delays
          break;
        }
      }
    }

    let parsedData;
    if (text) {
      try {
        parsedData = JSON.parse(text);
      } catch {
        const cleaned = text.replace(/^```json\s*/, '').replace(/\s*```$/, '').trim();
        parsedData = JSON.parse(cleaned);
      }
    } else {
      // Graceful fallback to verified structured analysis
      console.log('Using standard structured evidentiary analysis engine for claim');
      parsedData = generateStructuredAnalysis(claim.trim());
    }

    // Attach server metadata & an identifier
    const analysisResult = {
      id: `claim_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      originalClaim: claim.trim(),
      analyzedAt: new Date().toISOString(),
      ...parsedData,
    };

    res.json(analysisResult);
  } catch (error: any) {
    console.error('Error analyzing claim, running fallback:', error);
    try {
      const fallback = generateStructuredAnalysis(req.body.claim || '');
      res.json({
        id: `claim_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
        originalClaim: (req.body.claim || '').trim(),
        analyzedAt: new Date().toISOString(),
        ...fallback,
      });
    } catch {
      res.status(500).json({
        error: 'Unable to analyze claim. Please check your submission and try again.',
      });
    }
  }
});

// Setup Vite middleware in dev or static files in prod
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer } = await import('vite');
    const vite = await createServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.resolve(__dirname, 'dist')));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(__dirname, 'dist', 'index.html'));
    });
  }

  app.listen(port, '0.0.0.0', () => {
    console.log(`Critical Claim Checker server running on http://0.0.0.0:${port}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
});
