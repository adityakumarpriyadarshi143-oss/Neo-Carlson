import React, { useState } from 'react';
import {
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  XCircle,
  ChevronDown,
  ChevronUp,
  MessageSquare,
  Sparkles,
  Check,
  RotateCcw,
} from 'lucide-react';
import { ChecklistItem, ChecklistStatus } from '../types';

interface EvidenceChecklistSectionProps {
  items: ChecklistItem[];
  onUpdateItemUserStatus?: (id: string, status: 'checked' | 'questionable' | 'unresolved') => void;
  onUpdateItemNotes?: (id: string, notes: string) => void;
}

export const EvidenceChecklistSection: React.FC<EvidenceChecklistSectionProps> = ({
  items,
  onUpdateItemUserStatus,
  onUpdateItemNotes,
}) => {
  const [expandedId, setExpandedId] = useState<string | null>(items[0]?.id || null);
  const [editingNotesId, setEditingNotesId] = useState<string | null>(null);
  const [noteInputs, setNoteInputs] = useState<Record<string, string>>({});

  const toggleExpand = (id: string) => {
    setExpandedId((prev) => (prev === id ? null : id));
  };

  const handleNotesChange = (id: string, val: string) => {
    setNoteInputs((prev) => ({ ...prev, [id]: val }));
  };

  const handleSaveNotes = (id: string) => {
    const text = noteInputs[id] ?? '';
    onUpdateItemNotes?.(id, text);
    setEditingNotesId(null);
  };

  const getStatusBadge = (status: ChecklistStatus, statusText: string) => {
    switch (status) {
      case 'verified':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-emerald-800">
            <CheckCircle2 className="w-3.5 h-3.5 text-emerald-600" />
            <span>{statusText || 'Documented'}</span>
          </span>
        );
      case 'mixed':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-amber-800">
            <AlertCircle className="w-3.5 h-3.5 text-amber-600" />
            <span>{statusText || 'Mixed / Nuanced'}</span>
          </span>
        );
      case 'lacking':
      case 'unverified':
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-700">
            <XCircle className="w-3.5 h-3.5 text-stone-400" />
            <span>{statusText || 'Lacking Verification'}</span>
          </span>
        );
      case 'open':
      default:
        return (
          <span className="inline-flex items-center gap-1.5 text-xs font-medium text-stone-600">
            <HelpCircle className="w-3.5 h-3.5 text-stone-400" />
            <span>{statusText || 'Under Evaluation'}</span>
          </span>
        );
    }
  };

  return (
    <section className="bg-white border border-stone-200/90 rounded-xl p-6 sm:p-8 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-stone-100 gap-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-semibold text-stone-500 uppercase tracking-widest">
            Section 02
          </span>
          <span className="text-stone-300">/</span>
          <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-stone-900">
            Interactive Evidence Checklist
          </h2>
        </div>
        <p className="text-xs text-stone-500">
          Review 9 standard criteria · Click to inspect assessments & record notes
        </p>
      </div>

      {/* Checklist list */}
      <div className="divide-y divide-stone-100">
        {items.map((item, index) => {
          const isExpanded = expandedId === item.id;
          const isEditingNotes = editingNotesId === item.id;
          const currentNoteVal =
            noteInputs[item.id] !== undefined
              ? noteInputs[item.id]
              : item.userNotes || '';

          return (
            <div
              key={item.id || index}
              className={`py-4 transition-colors ${isExpanded ? 'bg-stone-50/40 rounded-lg px-3' : 'px-1'}`}
            >
              {/* Question Row Header */}
              <div className="flex items-start justify-between gap-4">
                <button
                  type="button"
                  onClick={() => toggleExpand(item.id)}
                  className="flex items-start gap-3.5 text-left flex-1 group cursor-pointer"
                >
                  <span className="font-mono text-xs text-stone-400 pt-0.5 w-5 shrink-0">
                    {String(index + 1).padStart(2, '0')}.
                  </span>
                  <div className="space-y-1">
                    <span className="font-medium text-stone-900 text-sm sm:text-base group-hover:text-stone-700 transition-colors leading-snug">
                      {item.question}
                    </span>
                    <div className="flex items-center gap-3">
                      {getStatusBadge(item.status, item.statusText)}
                      {item.userStatus && (
                        <>
                          <span className="text-stone-300">·</span>
                          <span className="text-xs font-mono text-stone-500 capitalize">
                            Your status: {item.userStatus}
                          </span>
                        </>
                      )}
                      {item.userNotes && (
                        <>
                          <span className="text-stone-300">·</span>
                          <span className="text-xs text-stone-500 flex items-center gap-1">
                            <MessageSquare className="w-3 h-3" /> Note saved
                          </span>
                        </>
                      )}
                    </div>
                  </div>
                </button>

                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    onClick={() => toggleExpand(item.id)}
                    className="p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors"
                    aria-label={isExpanded ? 'Collapse' : 'Expand'}
                  >
                    {isExpanded ? (
                      <ChevronUp className="w-4 h-4" />
                    ) : (
                      <ChevronDown className="w-4 h-4" />
                    )}
                  </button>
                </div>
              </div>

              {/* Expanded Assessment & Interactive Controls */}
              {isExpanded && (
                <div className="mt-4 pt-3 border-t border-stone-200/60 pl-8 space-y-4">
                  {/* Objective Assessment */}
                  <div>
                    <h4 className="text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1">
                      Objective Assessment
                    </h4>
                    <p className="font-serif-body text-stone-800 text-sm sm:text-base leading-relaxed">
                      {item.assessment}
                    </p>
                  </div>

                  {/* Critical Thinking Guidance */}
                  {item.guidance && (
                    <div className="bg-white border border-stone-200/70 rounded-md p-3 text-xs sm:text-sm text-stone-600">
                      <span className="font-semibold text-stone-800 block mb-0.5">
                        What to look for:
                      </span>
                      {item.guidance}
                    </div>
                  )}

                  {/* Interactive User Controls */}
                  <div className="pt-2 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs">
                    <div className="flex items-center gap-2">
                      <span className="text-stone-500 font-medium">Your verdict:</span>
                      <button
                        type="button"
                        onClick={() => onUpdateItemUserStatus?.(item.id, 'checked')}
                        className={`px-2.5 py-1 rounded border transition-colors ${
                          item.userStatus === 'checked'
                            ? 'bg-emerald-50 border-emerald-300 text-emerald-800 font-medium'
                            : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                        }`}
                      >
                        ✓ Verified by me
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdateItemUserStatus?.(item.id, 'questionable')}
                        className={`px-2.5 py-1 rounded border transition-colors ${
                          item.userStatus === 'questionable'
                            ? 'bg-amber-50 border-amber-300 text-amber-800 font-medium'
                            : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                        }`}
                      >
                        ? Questionable
                      </button>
                      <button
                        type="button"
                        onClick={() => onUpdateItemUserStatus?.(item.id, 'unresolved')}
                        className={`px-2.5 py-1 rounded border transition-colors ${
                          item.userStatus === 'unresolved'
                            ? 'bg-stone-100 border-stone-300 text-stone-800 font-medium'
                            : 'bg-white border-stone-200 text-stone-600 hover:bg-stone-50'
                        }`}
                      >
                        Needs Check
                      </button>
                    </div>

                    <div>
                      {!isEditingNotes && (
                        <button
                          type="button"
                          onClick={() => setEditingNotesId(item.id)}
                          className="text-stone-600 hover:text-stone-900 underline underline-offset-2 flex items-center gap-1"
                        >
                          <MessageSquare className="w-3.5 h-3.5" />
                          <span>{item.userNotes ? 'Edit My Note' : 'Add Note / Link'}</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* User Note Editor */}
                  {isEditingNotes && (
                    <div className="space-y-2 pt-1">
                      <textarea
                        rows={2}
                        value={currentNoteVal}
                        onChange={(e) => handleNotesChange(item.id, e.target.value)}
                        placeholder="Write down personal observations, citations, or questions regarding this evidence point..."
                        className="w-full p-2.5 text-xs sm:text-sm bg-white border border-stone-300 rounded focus:outline-none focus:ring-1 focus:ring-stone-400 text-stone-900"
                      />
                      <div className="flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => setEditingNotesId(null)}
                          className="px-2.5 py-1 text-xs text-stone-500 hover:text-stone-800"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={() => handleSaveNotes(item.id)}
                          className="px-3 py-1 text-xs font-medium bg-stone-900 text-white rounded hover:bg-stone-800"
                        >
                          Save Note
                        </button>
                      </div>
                    </div>
                  )}

                  {/* Display Saved Note */}
                  {item.userNotes && !isEditingNotes && (
                    <div className="bg-stone-50 border-l-2 border-stone-300 p-2.5 text-xs text-stone-700 italic">
                      <span className="font-semibold not-italic text-stone-900 block mb-0.5">
                        Your Personal Note:
                      </span>
                      "{item.userNotes}"
                    </div>
                  )}
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
