import React from 'react';
import { CheckCircle2, HelpCircle, XCircle, Library } from 'lucide-react';
import { ClaimAnalysis } from '../types';

interface ReliableSourcesSectionProps {
  sources: ClaimAnalysis['reliableSources'];
}

export const ReliableSourcesSection: React.FC<ReliableSourcesSectionProps> = ({ sources }) => {
  return (
    <section className="bg-white border border-stone-200/90 rounded-xl p-6 sm:p-8 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-stone-100 gap-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-semibold text-stone-500 uppercase tracking-widest">
            Section 04
          </span>
          <span className="text-stone-300">/</span>
          <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-stone-900">
            What Reliable Sources Indicate
          </h2>
        </div>
        <span className="text-xs text-stone-500 font-medium">
          Mainstream evidence-based consensus & documentation
        </span>
      </div>

      {/* Synthesis Overview */}
      {sources.summaryOverview && (
        <div className="bg-stone-50/70 border border-stone-200/60 rounded-lg p-4 sm:p-5">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">
            <Library className="w-3.5 h-3.5 text-stone-400" />
            <span>State of Documented Knowledge</span>
          </div>
          <p className="font-serif-body text-stone-800 text-sm sm:text-base leading-relaxed">
            {sources.summaryOverview}
          </p>
        </div>
      )}

      {/* 3 Structured Tiers */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 pt-2">
        {/* Tier 1: Well-supported facts */}
        <div className="border border-stone-200 rounded-lg p-5 bg-stone-50/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-stone-200">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
              <h3 className="font-serif-display text-base sm:text-lg font-bold text-stone-900">
                Well-Supported Facts
              </h3>
            </div>
            {sources.wellSupportedFacts?.length > 0 ? (
              <ul className="space-y-2.5 font-serif-body text-xs sm:text-sm text-stone-700">
                {sources.wellSupportedFacts.map((fact, idx) => (
                  <li key={idx} className="flex items-start gap-2 leading-relaxed">
                    <span className="text-emerald-600 font-bold mt-0.5">•</span>
                    <span>{fact}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-stone-500 italic font-serif-body">
                No foundational facts currently verified in relation to this specific claim.
              </p>
            )}
          </div>
          <div className="mt-4 pt-3 border-t border-stone-100 text-[11px] text-stone-400">
            Backed by physical evidence or consensus
          </div>
        </div>

        {/* Tier 2: Uncertain or disputed points */}
        <div className="border border-stone-200 rounded-lg p-5 bg-stone-50/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-stone-200">
              <HelpCircle className="w-4 h-4 text-amber-600 shrink-0" />
              <h3 className="font-serif-display text-base sm:text-lg font-bold text-stone-900">
                Uncertain / Disputed Points
              </h3>
            </div>
            {sources.uncertainOrDisputedPoints?.length > 0 ? (
              <ul className="space-y-2.5 font-serif-body text-xs sm:text-sm text-stone-700">
                {sources.uncertainOrDisputedPoints.map((point, idx) => (
                  <li key={idx} className="flex items-start gap-2 leading-relaxed">
                    <span className="text-amber-600 font-bold mt-0.5">•</span>
                    <span>{point}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-stone-500 italic font-serif-body">
                No significant scientific or factual ambiguity currently remains on this point.
              </p>
            )}
          </div>
          <div className="mt-4 pt-3 border-t border-stone-100 text-[11px] text-stone-400">
            Legitimate gray areas or ongoing research
          </div>
        </div>

        {/* Tier 3: Claims lacking credible supporting evidence */}
        <div className="border border-stone-200 rounded-lg p-5 bg-stone-50/30 flex flex-col justify-between">
          <div>
            <div className="flex items-center gap-2 mb-3 pb-2 border-b border-stone-200">
              <XCircle className="w-4 h-4 text-stone-500 shrink-0" />
              <h3 className="font-serif-display text-base sm:text-lg font-bold text-stone-900">
                Lacking Credible Evidence
              </h3>
            </div>
            {sources.claimsLackingCredibleEvidence?.length > 0 ? (
              <ul className="space-y-2.5 font-serif-body text-xs sm:text-sm text-stone-700">
                {sources.claimsLackingCredibleEvidence.map((unsupported, idx) => (
                  <li key={idx} className="flex items-start gap-2 leading-relaxed">
                    <span className="text-stone-400 font-bold mt-0.5">•</span>
                    <span>{unsupported}</span>
                  </li>
                ))}
              </ul>
            ) : (
              <p className="text-xs text-stone-500 italic font-serif-body">
                No completely baseless claims identified in this submission.
              </p>
            )}
          </div>
          <div className="mt-4 pt-3 border-t border-stone-100 text-[11px] text-stone-400">
            Unsubstantiated or refuted assertions
          </div>
        </div>
      </div>
    </section>
  );
};
