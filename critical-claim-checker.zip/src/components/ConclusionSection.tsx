import React from 'react';
import { ShieldAlert, ShieldCheck, HelpCircle, AlertTriangle } from 'lucide-react';
import { ClaimAnalysis, ConclusionLabel } from '../types';

interface ConclusionSectionProps {
  conclusion: ClaimAnalysis['conclusion'];
}

export const ConclusionSection: React.FC<ConclusionSectionProps> = ({ conclusion }) => {
  const getBadgeStyle = (label: ConclusionLabel) => {
    switch (label) {
      case 'Well supported':
        return {
          icon: <ShieldCheck className="w-5 h-5 text-emerald-700" />,
          containerClass: 'bg-emerald-50/70 border-emerald-300 text-emerald-950',
          badgeText: 'text-emerald-900 font-semibold',
        };
      case 'Partly supported, important gaps remain':
        return {
          icon: <AlertTriangle className="w-5 h-5 text-amber-700" />,
          containerClass: 'bg-amber-50/70 border-amber-300 text-amber-950',
          badgeText: 'text-amber-900 font-semibold',
        };
      case 'Not currently supported by credible evidence':
        return {
          icon: <ShieldAlert className="w-5 h-5 text-stone-700" />,
          containerClass: 'bg-stone-100/80 border-stone-300 text-stone-900',
          badgeText: 'text-stone-900 font-semibold',
        };
      case 'Insufficient information to judge':
      default:
        return {
          icon: <HelpCircle className="w-5 h-5 text-stone-600" />,
          containerClass: 'bg-stone-50 border-stone-300 text-stone-900',
          badgeText: 'text-stone-800 font-semibold',
        };
    }
  };

  const style = getBadgeStyle(conclusion.label);

  return (
    <section className="bg-white border border-stone-200/90 rounded-xl p-6 sm:p-8 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-stone-100 gap-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-semibold text-stone-500 uppercase tracking-widest">
            Section 06
          </span>
          <span className="text-stone-300">/</span>
          <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-stone-900">
            Balanced Conclusion
          </h2>
        </div>
        <span className="text-xs text-stone-500 font-medium">
          Empirical evaluation without claiming certainty beyond evidence
        </span>
      </div>

      {/* Main Conclusion Callout */}
      <div className={`border rounded-xl p-5 sm:p-6 ${style.containerClass} space-y-4`}>
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-black/10">
          <div className="flex items-center gap-2.5">
            {style.icon}
            <span className="text-xs uppercase tracking-wider font-mono text-stone-500">
              Evaluation Status:
            </span>
            <span className={`text-base sm:text-lg font-serif-display ${style.badgeText}`}>
              "{conclusion.label}"
            </span>
          </div>
          <span className="text-[11px] text-stone-500 font-mono">
            Standard Verification Scale
          </span>
        </div>

        {/* 2-4 sentence explanation */}
        <p className="font-serif-body text-base sm:text-lg leading-relaxed">
          {conclusion.explanation}
        </p>

        <div className="text-xs text-stone-500 pt-2 border-t border-black/5 font-mono">
          Note: This conclusion reflects current publicly verifiable records and peer-reviewed consensus; science and historical inquiry remain open to new valid documentation.
        </div>
      </div>
    </section>
  );
};
