import React from 'react';
import { X, Trash2, Clock, ChevronRight, BookOpen } from 'lucide-react';
import { ClaimAnalysis } from '../types';

interface SavedReportsModalProps {
  isOpen: boolean;
  onClose: () => void;
  savedReports: ClaimAnalysis[];
  onSelectReport: (report: ClaimAnalysis) => void;
  onDeleteReport: (id: string) => void;
  onClearAll: () => void;
}

export const SavedReportsModal: React.FC<SavedReportsModalProps> = ({
  isOpen,
  onClose,
  savedReports,
  onSelectReport,
  onDeleteReport,
  onClearAll,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-xs">
      <div className="bg-white border border-stone-200 rounded-xl shadow-xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="flex items-center justify-between p-5 border-b border-stone-200 bg-stone-50/70">
          <div className="flex items-center gap-2.5">
            <BookOpen className="w-4 h-4 text-stone-700" />
            <h3 className="font-serif-display text-lg font-bold text-stone-900">
              Your Research Notebook
            </h3>
            <span className="text-xs font-mono text-stone-500">
              ({savedReports.length} {savedReports.length === 1 ? 'saved claim' : 'saved claims'})
            </span>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors"
            aria-label="Close saved reports dialog"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-5 divide-y divide-stone-100">
          {savedReports.length === 0 ? (
            <div className="py-12 text-center space-y-2">
              <Clock className="w-8 h-8 text-stone-300 mx-auto" />
              <h4 className="font-serif-display text-base font-semibold text-stone-700">
                Notebook is Empty
              </h4>
              <p className="text-xs text-stone-500 max-w-sm mx-auto font-serif-body">
                When you analyze claims, click "Save to Notebook" to retain your findings, evidence checklist checks, and personal notes.
              </p>
            </div>
          ) : (
            savedReports.map((report) => (
              <div
                key={report.id}
                className="py-3.5 first:pt-0 last:pb-0 flex items-start justify-between gap-4 group"
              >
                <button
                  type="button"
                  onClick={() => {
                    onSelectReport(report);
                    onClose();
                  }}
                  className="flex-1 text-left space-y-1 cursor-pointer"
                >
                  <div className="flex items-center gap-2 text-xs text-stone-500 font-mono">
                    <span>{new Date(report.analyzedAt).toLocaleDateString()}</span>
                    <span>·</span>
                    <span className="font-semibold text-stone-800">
                      {report.conclusion?.label}
                    </span>
                  </div>
                  <h4 className="font-serif-display text-base font-semibold text-stone-900 group-hover:text-stone-700 transition-colors line-clamp-1">
                    {report.summary?.centralFactualQuestion || report.originalClaim}
                  </h4>
                  <p className="text-xs text-stone-600 line-clamp-2 font-serif-body">
                    "{report.originalClaim}"
                  </p>
                </button>

                <div className="flex items-center gap-1.5 shrink-0 pt-1">
                  <button
                    type="button"
                    onClick={() => onDeleteReport(report.id)}
                    className="p-1.5 text-stone-400 hover:text-red-700 hover:bg-stone-100 rounded transition-colors"
                    title="Remove from notebook"
                    aria-label="Delete this saved claim report"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      onSelectReport(report);
                      onClose();
                    }}
                    className="p-1.5 text-stone-400 hover:text-stone-900 hover:bg-stone-100 rounded transition-colors"
                    aria-label="Open report"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Modal Footer */}
        {savedReports.length > 0 && (
          <div className="p-4 border-t border-stone-200 bg-stone-50/50 flex items-center justify-between text-xs">
            <span className="text-stone-500">
              Stored locally on this device.
            </span>
            <button
              type="button"
              onClick={onClearAll}
              className="text-stone-500 hover:text-red-700 transition-colors font-medium"
            >
              Clear entire notebook
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
