import React from 'react';
import { ShieldCheck, AlertCircle } from 'lucide-react';

interface DisclaimerBannerProps {
  urgentNotice?: string | null;
}

export const DisclaimerBanner: React.FC<DisclaimerBannerProps> = ({ urgentNotice }) => {
  return (
    <div className="space-y-3">
      {/* Primary General Disclaimer */}
      <div className="border border-stone-200/90 bg-stone-100/60 rounded-lg p-3.5 sm:p-4 text-xs sm:text-sm text-stone-600 flex items-start gap-3">
        <ShieldCheck className="w-4 h-4 text-stone-500 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-semibold text-stone-800">Notice for careful inquiry: </span>
          This tool supports critical thinking. It does not replace expert advice, official investigations, or primary-source verification.
        </div>
      </div>

      {/* Safety notice if claim involves violence, self-harm, medical emergency, or vital healthcare */}
      {urgentNotice && (
        <div className="border border-amber-300 bg-amber-50/90 rounded-lg p-4 text-xs sm:text-sm text-amber-900 flex items-start gap-3">
          <AlertCircle className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
          <div className="leading-relaxed">
            <span className="font-bold block mb-0.5">Important Safety Advisory:</span>
            {urgentNotice}
          </div>
        </div>
      )}
    </div>
  );
};
