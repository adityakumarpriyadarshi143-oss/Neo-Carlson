import React, { useState } from 'react';
import { X, CheckCircle, HelpCircle, Brain, BookOpen } from 'lucide-react';

interface MethodologyModalProps {
  isOpen: boolean;
  onClose: () => void;
  initialTab?: 'framework' | 'reasoning';
}

export const MethodologyModal: React.FC<MethodologyModalProps> = ({
  isOpen,
  onClose,
  initialTab = 'framework',
}) => {
  const [activeTab, setActiveTab] = useState<'framework' | 'reasoning'>(initialTab);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/40 backdrop-blur-xs">
      <div className="bg-white border border-stone-200 rounded-xl shadow-xl w-full max-w-3xl max-h-[85vh] flex flex-col overflow-hidden">
        {/* Modal Header */}
        <div className="p-5 border-b border-stone-200 bg-stone-50/70 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <BookOpen className="w-5 h-5 text-stone-700" />
            <h3 className="font-serif-display text-xl font-bold text-stone-900">
              Critical Thinking Guide & Standards
            </h3>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-md transition-colors"
            aria-label="Close guide modal"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab switch */}
        <div className="flex border-b border-stone-200 px-5 bg-white text-xs font-medium text-stone-600 gap-6">
          <button
            type="button"
            onClick={() => setActiveTab('framework')}
            className={`py-3 border-b-2 font-semibold transition-colors cursor-pointer ${
              activeTab === 'framework'
                ? 'border-stone-900 text-stone-900'
                : 'border-transparent hover:text-stone-900'
            }`}
          >
            The 9 Evidence Checklist Criteria
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('reasoning')}
            className={`py-3 border-b-2 font-semibold transition-colors cursor-pointer ${
              activeTab === 'reasoning'
                ? 'border-stone-900 text-stone-900'
                : 'border-transparent hover:text-stone-900'
            }`}
          >
            Common Reasoning Traps & Fallacies
          </button>
        </div>

        {/* Modal Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {activeTab === 'framework' ? (
            <div className="space-y-4">
              <p className="font-serif-body text-sm sm:text-base text-stone-700 leading-relaxed">
                When evaluating unverified claims, rumors, or theories, rigorous fact-checking and scientific inquiry rely on nine foundational questions:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs font-serif-body">
                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    01. Who originally made the claim?
                  </span>
                  Tracing the origin separates first-hand witnesses from chains of hearsay or anonymous forum posts.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    02. Is the source identifiable and credible?
                  </span>
                  Checks if the source has demonstrable expertise, conflict of interest, or past record of retractions.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    03. Is there direct, verifiable evidence?
                  </span>
                  Distinguishes tangible proof (documents, telemetry, physical samples) from anecdotes or assumptions.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    04. Have independent sources corroborated it?
                  </span>
                  Verification by competing organizations or third parties who have no incentive to coordinate.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    05. Do relevant experts agree?
                  </span>
                  Checks current peer-reviewed research and professional scientific or historical consensus.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    06. Are dates, names, images, or stats accurate?
                  </span>
                  Verifies that dates line up, images haven't been recycled from older events, and numbers aren't distorted.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    07. Could simpler explanations explain it?
                  </span>
                  Applies Ockham's Razor: preferring explanations that require the fewest unproven assumptions.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    08. What evidence would weaken the claim?
                  </span>
                  Falsifiability test: a claim that cannot be disproved by any possible observation cannot be tested scientifically.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40 sm:col-span-2">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    09. What evidence would strengthen the claim?
                  </span>
                  Identifies the exact empirical discoveries, primary records, or controlled trials that would turn an unverified hypothesis into proven fact.
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-4">
              <p className="font-serif-body text-sm sm:text-base text-stone-700 leading-relaxed">
                Human minds rely on intuitive heuristics that can occasionally mislead us. Recognizing these patterns gently is the hallmark of critical thinking:
              </p>

              <div className="space-y-3 pt-2 text-xs font-serif-body">
                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    Confirmation Bias
                  </span>
                  Noticing and remembering facts that match what we already believe while discounting or ignoring contrary evidence.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    Cherry-Picking Evidence
                  </span>
                  Selecting isolated outliers or atypical data points while omitting the wider body of systematic research.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    Appeal to Secrecy ("They Are Hiding It")
                  </span>
                  Treating the complete absence of evidence as proof of a high-level coverup, rendering the theory unfalsifiable.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    False Cause (Post Hoc Ergo Propter Hoc)
                  </span>
                  Assuming that because event B happened shortly after event A, event A must have caused event B.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    Appeal to Authority Without Evidence
                  </span>
                  Relying on a person's celebrity or credentials in an unrelated field instead of reviewing primary evidence.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    Overgeneralization
                  </span>
                  Taking a single isolated incident or small sample and asserting that it universally applies everywhere.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    Motivated Reasoning
                  </span>
                  Starting with an emotional conclusion first, then searching backwards for rationalizations to defend it.
                </div>

                <div className="border border-stone-200 p-3.5 rounded-lg bg-stone-50/40">
                  <span className="font-sans font-bold text-stone-900 block mb-1">
                    Unfalsifiable Claims
                  </span>
                  Constructing assertions in a way where any possible counter-evidence can be reinterpreted to fit the narrative.
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div className="p-4 border-t border-stone-200 bg-stone-50/50 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 text-xs font-semibold bg-stone-900 text-white rounded-lg hover:bg-stone-800 transition-colors"
          >
            Close Guide
          </button>
        </div>
      </div>
    </div>
  );
};
