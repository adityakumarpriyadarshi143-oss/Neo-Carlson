import React from 'react';
import { BookOpen, History, HelpCircle, Plus } from 'lucide-react';

interface HeaderProps {
  onNewAnalysis: () => void;
  onOpenHistory: () => void;
  onOpenMethodology: (tab?: 'framework' | 'reasoning') => void;
  savedCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onNewAnalysis,
  onOpenHistory,
  onOpenMethodology,
  savedCount,
}) => {
  return (
    <header className="border-b border-stone-200/80 bg-[#fbf9f5]/90 backdrop-blur-md sticky top-0 z-30">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Brand title */}
        <button
          onClick={onNewAnalysis}
          className="text-left font-serif-display text-xl sm:text-2xl font-bold tracking-tight text-stone-900 whitespace-nowrap shrink-0 hover:text-stone-700 transition-colors"
        >
          Critical Claim Checker
        </button>

        {/* Zone 2: Navigation links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium text-stone-600">
          <button
            onClick={onNewAnalysis}
            className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
          >
            Examine
          </button>
          <button
            onClick={() => onOpenMethodology('framework')}
            className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
          >
            Checklist Guide
          </button>
          <button
            onClick={() => onOpenMethodology('reasoning')}
            className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0"
          >
            Reasoning Traps
          </button>
          <button
            onClick={onOpenHistory}
            className="hover:text-stone-900 transition-colors whitespace-nowrap shrink-0 flex items-center gap-1.5"
          >
            <span>Saved Notebook</span>
            {savedCount > 0 && (
              <span className="text-xs font-mono text-stone-500">
                ({savedCount})
              </span>
            )}
          </button>
        </nav>

        {/* Zone 3: Primary action */}
        <div className="flex items-center gap-2.5 shrink-0">
          <button
            onClick={onOpenHistory}
            className="md:hidden p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
            title="Saved Analyses"
            aria-label="Saved Notebook"
          >
            <History className="w-4 h-4" />
          </button>
          <button
            onClick={() => onOpenMethodology('framework')}
            className="p-2 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-lg transition-colors"
            title="Guide & Methodology"
            aria-label="Guide and Methodology"
          >
            <HelpCircle className="w-4 h-4" />
          </button>
          <button
            onClick={onNewAnalysis}
            className="flex items-center gap-1.5 px-3.5 py-1.5 text-xs font-semibold text-stone-900 bg-stone-200/80 hover:bg-stone-300/80 rounded-md transition-colors whitespace-nowrap shrink-0 cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Claim</span>
          </button>
        </div>
      </div>
    </header>
  );
};
