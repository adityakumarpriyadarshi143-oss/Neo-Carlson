import React, { useState } from 'react';
import { Compass, CheckSquare, Square, ArrowUpRight } from 'lucide-react';
import { VerificationStep } from '../types';

interface NextStepsSectionProps {
  steps: VerificationStep[];
}

export const NextStepsSection: React.FC<NextStepsSectionProps> = ({ steps }) => {
  const [completedSteps, setCompletedSteps] = useState<Record<number, boolean>>({});

  const toggleStep = (idx: number) => {
    setCompletedSteps((prev) => ({ ...prev, [idx]: !prev[idx] }));
  };

  return (
    <section className="bg-white border border-stone-200/90 rounded-xl p-6 sm:p-8 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-stone-100 gap-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-semibold text-stone-500 uppercase tracking-widest">
            Section 07
          </span>
          <span className="text-stone-300">/</span>
          <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-stone-900">
            Recommended Next Steps
          </h2>
        </div>
        <span className="text-xs text-stone-500 font-medium">
          3 practical verification avenues
        </span>
      </div>

      <p className="font-serif-body text-stone-600 text-sm sm:text-base leading-relaxed">
        True critical thinking does not rely on a single analysis. Here are three recommended empirical steps you can undertake to inspect primary records and independent evaluations directly.
      </p>

      {/* 3 Step Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5 pt-1">
        {steps.map((step, idx) => {
          const isDone = !!completedSteps[idx];
          return (
            <div
              key={idx}
              onClick={() => toggleStep(idx)}
              className={`border rounded-lg p-5 cursor-pointer transition-all flex flex-col justify-between ${
                isDone
                  ? 'bg-stone-50/90 border-stone-300 opacity-80'
                  : 'bg-white hover:border-stone-400 border-stone-200 hover:shadow-xs'
              }`}
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-semibold text-stone-400">
                      Step {idx + 1}
                    </span>
                  </div>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleStep(idx);
                    }}
                    className="text-stone-400 hover:text-stone-700"
                    aria-label={`Mark step ${idx + 1} as completed`}
                  >
                    {isDone ? (
                      <CheckSquare className="w-4 h-4 text-emerald-600" />
                    ) : (
                      <Square className="w-4 h-4 text-stone-300" />
                    )}
                  </button>
                </div>

                <h3
                  className={`font-serif-display text-base sm:text-lg font-bold text-stone-900 leading-snug ${
                    isDone ? 'line-through text-stone-500' : ''
                  }`}
                >
                  {step.title}
                </h3>

                <p className="font-serif-body text-xs sm:text-sm text-stone-600 leading-relaxed">
                  {step.action}
                </p>
              </div>

              {step.concreteTarget && (
                <div className="mt-4 pt-3 border-t border-stone-100 flex items-center justify-between text-xs text-stone-500 font-mono">
                  <span className="truncate">{step.concreteTarget}</span>
                  <Compass className="w-3.5 h-3.5 text-stone-400 shrink-0 ml-1" />
                </div>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
