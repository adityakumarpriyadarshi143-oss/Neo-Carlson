import React, { useState } from 'react';
import { Search, Loader2, Sparkles, X, ArrowRight } from 'lucide-react';
import { SAMPLE_CLAIMS, SampleClaim } from '../data/sampleClaims';

interface ClaimInputSectionProps {
  claimText: string;
  setClaimText: (val: string) => void;
  onAnalyze: () => void;
  isLoading: boolean;
}

export const ClaimInputSection: React.FC<ClaimInputSectionProps> = ({
  claimText,
  setClaimText,
  onAnalyze,
  isLoading,
}) => {
  const [activeSampleId, setActiveSampleId] = useState<string | null>(null);

  const handleSelectSample = (sample: SampleClaim) => {
    setActiveSampleId(sample.id);
    setClaimText(sample.claimText);
  };

  const handleClear = () => {
    setClaimText('');
    setActiveSampleId(null);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!claimText.trim() || isLoading) return;
    onAnalyze();
  };

  return (
    <section className="bg-white border border-stone-200/90 rounded-xl p-6 sm:p-8 shadow-xs">
      <div className="mb-6">
        <h1 className="font-serif-display text-2xl sm:text-3xl lg:text-4xl font-semibold text-stone-900 tracking-tight">
          Examine a Claim with Care & Rigor
        </h1>
        <p className="font-serif-body text-stone-600 mt-2 text-base sm:text-lg leading-relaxed max-w-3xl">
          Paste a story, viral post, headline, or claim below. We will dissect the evidence, examine the underlying logic, summarize reliable findings, and pose better questions—without mockery or judgment.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="relative">
          <label htmlFor="claim-input" className="sr-only">
            Claim or text to examine
          </label>
          <textarea
            id="claim-input"
            rows={5}
            value={claimText}
            onChange={(e) => {
              setClaimText(e.target.value);
              setActiveSampleId(null);
            }}
            placeholder="Paste a claim, article excerpt, social-media post, video title, or link description here..."
            className="w-full p-4 text-stone-900 bg-stone-50/70 border border-stone-200 rounded-lg focus:bg-white focus:outline-none focus:ring-2 focus:ring-stone-400 focus:border-stone-400 font-serif-body text-base leading-relaxed resize-y placeholder:text-stone-400 transition-colors"
            disabled={isLoading}
          />
          {claimText && !isLoading && (
            <button
              type="button"
              onClick={handleClear}
              className="absolute top-3 right-3 p-1.5 text-stone-400 hover:text-stone-700 bg-white/90 hover:bg-stone-100 rounded-md transition-colors"
              title="Clear input"
              aria-label="Clear input text"
            >
              <X className="w-4 h-4" />
            </button>
          )}
        </div>

        {/* Input Footer Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pt-1">
          <div className="text-xs text-stone-500 font-mono">
            <span>{claimText.trim().length} characters</span>
            {claimText.trim().length > 0 && (
              <>
                <span className="mx-2">·</span>
                <span>~{claimText.trim().split(/\s+/).filter(Boolean).length} words</span>
              </>
            )}
          </div>

          <div className="flex items-center gap-3">
            <button
              type="submit"
              disabled={!claimText.trim() || isLoading}
              className={`inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg text-sm font-semibold tracking-wide transition-all ${
                !claimText.trim() || isLoading
                  ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                  : 'bg-stone-900 hover:bg-stone-800 text-white shadow-xs cursor-pointer active:scale-[0.99]'
              }`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin text-stone-300" />
                  <span>Examining claim...</span>
                </>
              ) : (
                <>
                  <Search className="w-4 h-4 text-stone-300" />
                  <span>Analyze claim</span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>

      {/* Curated Sample Claims */}
      <div className="mt-8 pt-6 border-t border-stone-100">
        <div className="flex items-center gap-2 mb-3 text-xs font-semibold uppercase tracking-wider text-stone-500">
          <Sparkles className="w-3.5 h-3.5 text-stone-400" />
          <span>Or try a sample claim to explore the framework:</span>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
          {SAMPLE_CLAIMS.map((sample) => (
            <button
              key={sample.id}
              type="button"
              onClick={() => handleSelectSample(sample)}
              className={`text-left p-3 rounded-lg border transition-all text-xs ${
                activeSampleId === sample.id
                  ? 'bg-stone-100/90 border-stone-400 text-stone-900 ring-1 ring-stone-300'
                  : 'bg-stone-50/50 hover:bg-stone-100/60 border-stone-200/80 text-stone-700'
              }`}
            >
              <div className="font-semibold text-stone-900 mb-1 flex items-center justify-between">
                <span>{sample.title}</span>
                <span className="text-[11px] text-stone-500 font-normal">
                  {sample.category}
                </span>
              </div>
              <p className="line-clamp-2 text-stone-600 font-serif-body">
                "{sample.claimText}"
              </p>
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
