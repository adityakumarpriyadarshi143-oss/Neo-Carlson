import React, { useState } from 'react';
import { HelpCircle, Copy, Check, MessageSquare } from 'lucide-react';
import { BetterQuestion } from '../types';

interface BetterQuestionsSectionProps {
  questions: BetterQuestion[];
}

export const BetterQuestionsSection: React.FC<BetterQuestionsSectionProps> = ({ questions }) => {
  const [copiedIdx, setCopiedIdx] = useState<number | null>(null);
  const [copiedAll, setCopiedAll] = useState(false);

  const handleCopyOne = (text: string, idx: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIdx(idx);
    setTimeout(() => setCopiedIdx(null), 2000);
  };

  const handleCopyAll = () => {
    const formatted = questions
      .map((q, i) => `${i + 1}. ${q.question}\n   Purpose: ${q.purpose}`)
      .join('\n\n');
    navigator.clipboard.writeText(formatted);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  return (
    <section className="bg-white border border-stone-200/90 rounded-xl p-6 sm:p-8 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-stone-100 gap-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-semibold text-stone-500 uppercase tracking-widest">
            Section 05
          </span>
          <span className="text-stone-300">/</span>
          <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-stone-900">
            Better Questions to Ask
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={handleCopyAll}
            className="text-xs text-stone-600 hover:text-stone-900 border border-stone-200 hover:bg-stone-50 px-2.5 py-1 rounded transition-colors flex items-center gap-1.5"
          >
            {copiedAll ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copiedAll ? 'Copied all 5' : 'Copy all 5 questions'}</span>
          </button>
        </div>
      </div>

      <p className="font-serif-body text-stone-600 text-sm sm:text-base leading-relaxed">
        Curiosity thrives on constructive inquiries. Instead of arguing over conclusions, asking these five neutral questions can help clarify facts with primary sources or specialists.
      </p>

      {/* 5 Questions */}
      <div className="space-y-3.5 pt-1">
        {questions.map((q, idx) => (
          <div
            key={idx}
            className="border border-stone-200/80 rounded-lg p-4 sm:p-5 hover:border-stone-300 transition-colors bg-stone-50/20"
          >
            <div className="flex items-start justify-between gap-4">
              <div className="flex items-start gap-3 flex-1">
                <span className="font-mono text-xs font-semibold text-stone-400 mt-1 w-5 shrink-0">
                  {String(idx + 1).padStart(2, '0')}.
                </span>
                <div className="space-y-1.5">
                  <h3 className="font-serif-display text-base sm:text-lg font-semibold text-stone-900 leading-snug">
                    {q.question}
                  </h3>
                  <p className="font-serif-body text-xs sm:text-sm text-stone-600 leading-relaxed">
                    <span className="font-sans font-medium text-stone-500">Why this helps: </span>
                    {q.purpose}
                  </p>
                </div>
              </div>

              <button
                type="button"
                onClick={() => handleCopyOne(q.question, idx)}
                className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded transition-colors shrink-0"
                title="Copy question"
                aria-label={`Copy question ${idx + 1}`}
              >
                {copiedIdx === idx ? (
                  <Check className="w-4 h-4 text-emerald-600" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </button>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
