import React from 'react';
import { Lightbulb, CheckCircle, Scale } from 'lucide-react';
import { ReasoningIssue } from '../types';

interface ReasoningReviewSectionProps {
  patterns: ReasoningIssue[];
  overallAssessment: string;
}

export const ReasoningReviewSection: React.FC<ReasoningReviewSectionProps> = ({
  patterns,
  overallAssessment,
}) => {
  return (
    <section className="bg-white border border-stone-200/90 rounded-xl p-6 sm:p-8 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-stone-100 gap-2">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-semibold text-stone-500 uppercase tracking-widest">
            Section 03
          </span>
          <span className="text-stone-300">/</span>
          <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-stone-900">
            Reasoning Review
          </h2>
        </div>
        <span className="text-xs text-stone-500 font-medium">
          Examining cognitive patterns & logical structures gently
        </span>
      </div>

      {/* Overall Assessment */}
      {overallAssessment && (
        <div className="bg-stone-50/70 border border-stone-200/60 rounded-lg p-4 sm:p-5">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">
            <Scale className="w-3.5 h-3.5 text-stone-400" />
            <span>Structural Observation</span>
          </div>
          <p className="font-serif-body text-stone-800 text-sm sm:text-base leading-relaxed">
            {overallAssessment}
          </p>
        </div>
      )}

      {/* Detected Patterns */}
      {patterns.length > 0 ? (
        <div className="space-y-4">
          <div className="text-xs font-semibold uppercase tracking-wider text-stone-500">
            Identified Patterns in This Claim ({patterns.length}):
          </div>
          <div className="grid grid-cols-1 gap-4">
            {patterns.map((pattern, idx) => (
              <div
                key={idx}
                className="border border-stone-200 rounded-lg p-4 sm:p-5 hover:border-stone-300 transition-colors bg-white"
              >
                <div className="flex items-baseline justify-between gap-4 mb-2">
                  <h3 className="font-serif-display text-lg font-bold text-stone-900">
                    {pattern.name}
                  </h3>
                  <span className="text-[11px] font-mono text-stone-400 uppercase tracking-wider">
                    Pattern {idx + 1}
                  </span>
                </div>

                <div className="space-y-3 font-serif-body">
                  <div>
                    <span className="text-xs font-sans font-semibold text-stone-500 uppercase tracking-wider block mb-1">
                      How it manifests here:
                    </span>
                    <p className="text-stone-800 text-sm sm:text-base leading-relaxed">
                      {pattern.explanation}
                    </p>
                  </div>

                  {pattern.constructiveAlternative && (
                    <div className="bg-amber-50/50 border border-amber-200/60 rounded-md p-3 text-xs sm:text-sm text-stone-700">
                      <div className="flex items-center gap-1.5 font-sans font-semibold text-amber-900 mb-1">
                        <Lightbulb className="w-3.5 h-3.5 text-amber-700" />
                        <span>A constructive alternative perspective:</span>
                      </div>
                      <p className="leading-relaxed">
                        {pattern.constructiveAlternative}
                      </p>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="border border-emerald-200/80 bg-emerald-50/40 rounded-lg p-5 flex items-start gap-3.5">
          <CheckCircle className="w-5 h-5 text-emerald-600 shrink-0 mt-0.5" />
          <div className="space-y-1">
            <h3 className="text-sm font-semibold text-emerald-900">
              No Standard Fallacy Traps Identified
            </h3>
            <p className="text-xs sm:text-sm text-emerald-800 font-serif-body leading-relaxed">
              The phrasing of this claim does not exhibit obvious cognitive pitfalls like appeals to conspiracy, unfalsifiable assertions, or emotional overgeneralization. The inquiry can focus straightforwardly on empirical evidence.
            </p>
          </div>
        </div>
      )}
    </section>
  );
};
