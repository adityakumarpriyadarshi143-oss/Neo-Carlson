import React from 'react';
import { HelpCircle, FileText, Bookmark } from 'lucide-react';
import { ClaimAnalysis } from '../types';

interface PlainEnglishSummarySectionProps {
  summary: ClaimAnalysis['summary'];
  originalClaim: string;
}

export const PlainEnglishSummarySection: React.FC<PlainEnglishSummarySectionProps> = ({
  summary,
  originalClaim,
}) => {
  return (
    <section className="bg-white border border-stone-200/90 rounded-xl p-6 sm:p-8 shadow-xs space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between pb-4 border-b border-stone-100">
        <div className="flex items-center gap-3">
          <span className="font-mono text-xs font-semibold text-stone-500 uppercase tracking-widest">
            Section 01
          </span>
          <span className="text-stone-300">/</span>
          <h2 className="font-serif-display text-xl sm:text-2xl font-bold text-stone-900">
            Plain-English Summary
          </h2>
        </div>
        {summary.category && (
          <span className="text-xs text-stone-500 font-medium hidden sm:inline-block">
            Domain: {summary.category}
          </span>
        )}
      </div>

      {/* Original vs Restated */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        <div className="lg:col-span-5 bg-stone-50/80 border border-stone-200/70 rounded-lg p-4 sm:p-5">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-500 mb-2">
            <Bookmark className="w-3.5 h-3.5 text-stone-400" />
            <span>Original Submitted Claim</span>
          </div>
          <p className="font-serif-body text-stone-700 text-sm sm:text-base leading-relaxed italic">
            "{originalClaim}"
          </p>
        </div>

        <div className="lg:col-span-7 space-y-5">
          <div>
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-500 mb-2">
              <FileText className="w-3.5 h-3.5 text-stone-400" />
              <span>Neutral Restatement</span>
            </div>
            <p className="font-serif-body text-stone-800 text-base sm:text-lg leading-relaxed">
              {summary.plainEnglishRestatement}
            </p>
          </div>

          <div className="pt-4 border-t border-stone-100">
            <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-stone-500 mb-1.5">
              <HelpCircle className="w-3.5 h-3.5 text-stone-400" />
              <span>Central Factual Question</span>
            </div>
            <p className="font-serif-display text-lg sm:text-xl font-medium text-stone-900 leading-snug">
              {summary.centralFactualQuestion}
            </p>
          </div>
        </div>
      </div>
    </section>
  );
};
