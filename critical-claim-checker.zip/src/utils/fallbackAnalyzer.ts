import type { ClaimAnalysis, ConclusionLabel } from '../types.ts';

export function generateStructuredAnalysis(claimText: string): Omit<ClaimAnalysis, 'id' | 'analyzedAt' | 'originalClaim'> {
  const text = claimText.trim().toLowerCase();

  // Safety detection
  let safetyNotice: string | null = null;
  const isMedical = /cure|disease|diabetes|cancer|vaccin|virus|pathogen|medication|drug|dose|treatment|infection/i.test(text);
  const isEmergencyOrHarm = /suicide|kill|violence|bomb|weapon|emergency|assault|overdose/i.test(text);

  if (isEmergencyOrHarm) {
    safetyNotice =
      'Immediate Health & Safety Notice: If you or someone you know is in immediate physical danger, experiencing a medical crisis, or considering self-harm, please contact local emergency emergency services (e.g. 911/999/112) or professional crisis helplines immediately.';
  } else if (isMedical) {
    safetyNotice =
      'Medical Advice Advisory: This claim concerns health conditions or physical treatments. Do not discontinue prescribed treatments, alter insulin or medication dosages, or substitute medical care based on unverified internet remedies. Always consult a licensed physician, clinical endocrinologist, or qualified healthcare professional.';
  }

  // Topic recognition
  const isMoonLanding = /moon|apollo|kubrick|nasa|lunar|astronaut|1969/i.test(text);
  const isBermuda = /bermuda|triangle|ship|aircraft|disappear|ocean|magnetic/i.test(text);
  const isGarlicLemon = /garlic|lemon|cure.*diabetes|diabetes.*cure|empty stomach/i.test(text);
  const isSubliminal = /subliminal|popcorn|coca-cola|theater|vicary|invisible/i.test(text);
  const is5G = /5g|cell tower|radiation|millimeter|birds/i.test(text);

  if (isMoonLanding) {
    return {
      summary: {
        plainEnglishRestatement:
          'The claim states that the 1969 Apollo 11 lunar landing did not physically occur and was instead a staged theatrical production directed on a soundstage to claim a cold war geopolitical victory over the Soviet Union.',
        centralFactualQuestion:
          'Is there verified physical, optical, and independent international evidence that human astronauts physically traveled to and landed on the Moon in July 1969?',
        category: 'History & Space Exploration',
        safetyNotice,
      },
      evidenceChecklist: [
        {
          id: 'originator',
          question: 'Who originally made the claim?',
          status: 'verified',
          statusText: 'Documented Origin',
          assessment: 'Claims of a staged moon landing gained widespread public attention with Bill Kaysing’s self-published 1976 pamphlet "We Never Went to the Moon," written without technical or astronomical qualifications.',
          guidance: 'Trace whether the claim began with eyewitnesses and engineers or popularized decades later by independent speculative authors.',
        },
        {
          id: 'source_credibility',
          question: 'Is the source identifiable and credible?',
          status: 'lacking',
          statusText: 'No Relevant Technical Standing',
          assessment: 'Early proponents lacked aerospace credentials, optical physics training, or access to Saturn V telemetry. Allegations attributing direction to Stanley Kubrick were repeatedly dismissed by Kubrick’s family and archival records.',
          guidance: 'Check if the source has verifiable expertise in spaceflight telemetry, photography, or orbital mechanics.',
        },
        {
          id: 'direct_evidence',
          question: 'Is there direct, verifiable evidence?',
          status: 'verified',
          statusText: 'Substantial Physical Evidence Exists for Landing',
          assessment: 'NASA returned 382 kilograms of lunar geological samples containing unique micro-meteorite craters and zero cosmic hydration, confirmed by independent geologists across dozens of sovereign nations.',
          guidance: 'Look for tangible, physically testable artifacts rather than subjective interpretations of photographs.',
        },
        {
          id: 'corroboration',
          question: 'Have independent reliable sources corroborated it?',
          status: 'verified',
          statusText: 'Adversary & Independent Corroboration',
          assessment: 'The Soviet Union tracked the Apollo 11 spacecraft directly via radio radar and deep-space telemetry, acknowledging the US achievement immediately despite fierce Cold War rivalry.',
          guidance: 'Ask whether geopolitical adversaries who had every motivation to expose a fraud corroborated or refuted the event.',
        },
        {
          id: 'expert_consensus',
          question: 'Do relevant subject-matter experts agree?',
          status: 'verified',
          statusText: 'Universal Scientific Consensus',
          assessment: 'Astrophysicists, planetary scientists, aerospace engineers, and photographic historians universally agree that the Apollo landings were authentic.',
          guidance: 'Distinguish between consensus among thousands of working planetary scientists and fringe speculative commentary.',
        },
        {
          id: 'data_accuracy',
          question: 'Are dates, locations, names, images, or statistics accurate?',
          status: 'mixed',
          statusText: 'Misinterpreted Optical Details',
          assessment: 'Arguments claiming "no stars visible" or "fluttering flags" misinterpret basic camera exposure settings in bright lunar daylight and the inertia of a telescopic support wire in a vacuum.',
          guidance: 'Verify if optical anomalies have standard physics explanations under vacuum conditions and high shutter speeds.',
        },
        {
          id: 'simpler_explanations',
          question: 'Could simpler alternative explanations explain the evidence?',
          status: 'verified',
          statusText: 'Real Flight Far Simpler Than Conspiracy',
          assessment: 'Maintaining a seamless global conspiracy involving 400,000 engineers, astronauts, ground technicians, contractors, and foreign observers across 50 years would be practically impossible.',
          guidance: 'Apply Ockham’s Razor: evaluate how many tens of thousands of people would have to remain silent indefinitely.',
        },
        {
          id: 'falsifying_evidence',
          question: 'What evidence, if found, would weaken the claim?',
          status: 'verified',
          statusText: 'High-Resolution Orbital Imagery',
          assessment: 'High-resolution images of the Apollo descent stages, rover tracks, and scientific stations captured by NASA’s Lunar Reconnaissance Orbiter (LRO), Japan’s SELENE (Kaguya), and India’s Chandrayaan-2 directly weaken the staging claim.',
          guidance: 'Check if third-party orbiters have photographed the surface hardware.',
        },
        {
          id: 'strengthening_evidence',
          question: 'What evidence, if found, would strengthen the claim?',
          status: 'open',
          statusText: 'Authentic Production Records',
          assessment: 'The claim would require verified internal studio budgets, physical soundstage sets, or authentic deathbed disclosures corroborated by contemporaneous 1969 laboratory documents.',
          guidance: 'Clarify what concrete documentation would be necessary to substantiate a coverup.',
        },
      ],
      reasoningReview: {
        detectedPatterns: [
          {
            name: 'Appeal to Secrecy ("They Are Hiding It")',
            explanation: 'The hypothesis assumes that lack of public soundstage records is explained by total government concealment, turning absence of evidence into supposed proof of secrecy.',
            constructiveAlternative: 'Consider that a project involving over 400,000 contractors, scientists, and foreign tracking stations would be statistically impossible to conceal for half a century.',
          },
          {
            name: 'Cherry-Picking Evidence',
            explanation: 'Focusing exclusively on perceived optical oddities (e.g. shadow angles on uneven terrain) while ignoring physical lunar rock samples and laser retroreflector experiments.',
            constructiveAlternative: 'Weigh optical questions against the entire multi-disciplinary body of physical samples and independent orbital photography.',
          },
          {
            name: 'Unfalsifiable Claims',
            explanation: 'When independent foreign orbiters photograph the landing sites, proponents often respond by claiming that those foreign space agencies are also part of the conspiracy.',
            constructiveAlternative: 'Establish what specific, measurable finding would be accepted as definitive disproof.',
          },
        ],
        overallAssessment:
          'The moon landing staging theory relies heavily on optical intuitions derived from terrestrial studio lighting rather than vacuum physics, combined with the presumption of an unprecedentedly leak-free multi-decade conspiracy.',
      },
      reliableSources: {
        summaryOverview:
          'Extensive physical, historical, and multi-national photographic records confirm that six Apollo crewed missions successfully landed on the Moon between 1969 and 1972.',
        wellSupportedFacts: [
          '382 kilograms of lunar soil and rock samples were retrieved, exhibiting cosmic-ray exposure ages and chemical compositions distinct from terrestrial meteorites.',
          'Apollo laser retroreflector arrays left on the lunar surface continue to be pinged by independent observatories in the US, France, Germany, and Russia to measure lunar drift.',
          'The Soviet Union, which had both the technology to intercept Apollo transmissions and intense geopolitical motivation to expose a fraud, verified and recognized the mission.',
          'Third-party lunar orbiters from India (Chandrayaan-2) and Japan (Kaguya) have photographed the undisturbed Apollo descent hardware on the surface.',
        ],
        uncertainOrDisputedPoints: [
          'Historical debates exist regarding programmatic cost-efficiency and how political pressures influenced NASA’s technological choices, but not the physical reality of the flights.',
        ],
        claimsLackingCredibleEvidence: [
          'The assertion that Stanley Kubrick directed the footage in a soundstage has zero documentary support and was refuted by production archives.',
          'Claims that Van Allen radiation belts are instantly lethal ignore the thin aluminum shielding and rapid trajectory used by Apollo crews.',
        ],
      },
      betterQuestions: [
        {
          question: 'How did Soviet radio tracking stations and radar units follow Apollo 11’s deep-space trajectory in real time?',
          purpose: 'Examines Cold War geopolitical incentives and adversarial confirmation.',
        },
        {
          question: 'What mineralogical characteristics of lunar rocks (e.g. lack of water hydration and micrometeorite pitting) make them impossible to fake with 1960s materials science?',
          purpose: 'Focuses on empirical materials testing conducted by global geological labs.',
        },
        {
          question: 'How does laser ranging to the retroreflectors placed at the Apollo 11, 14, and 15 sites function for independent observatories today?',
          purpose: 'Highlights an active physical experiment anyone with high-power laser equipment can verify.',
        },
        {
          question: 'Why do flags appear to wave when planted in a vacuum, and what did vacuum-chamber testing reveal about fabric inertia?',
          purpose: 'Explores classical Newtonian physics under vacuum conditions.',
        },
        {
          question: 'What would have been required to keep 400,000 NASA, university, and contractor personnel from revealing a staged hoax across 50 years?',
          purpose: 'Applies statistical and historical models of institutional information security.',
        },
      ],
      conclusion: {
        label: 'Not currently supported by credible evidence',
        explanation:
          'The claim that the Apollo moon landings were staged contradicts massive, convergent physical evidence—including 382 kg of verified lunar rocks, active laser retroreflectors, and direct orbital photographs of the landing sites. Geopolitical rivals and independent observatories around the globe tracked the flights in real time. No credible documentation or technical evidence supporting a staged production has ever emerged.',
      },
      recommendedNextSteps: [
        {
          title: 'Review Lunar Rock Peer-Reviewed Catalogues',
          action: 'Examine geochemical analysis papers from NASA’s Curation facility and independent university research teams regarding lunar basalts.',
          concreteTarget: 'NASA Lunar Sample Compendium & Meteoritical Society publications',
        },
        {
          title: 'Inspect Independent Orbital High-Resolution Imagery',
          action: 'View surface photography captured by India’s Chandrayaan-2 and NASA’s Lunar Reconnaissance Orbiter showing Apollo descent stages and tracks.',
          concreteTarget: 'ISRO Chandrayaan-2 Data Archive & LROC Archive',
        },
        {
          title: 'Examine Cold War Tracking Records',
          action: 'Read historical declassified archives detailing the Soviet Space Agency’s radio-interception and tracking of Apollo telemetry.',
          concreteTarget: 'National Security Archive & Russian Academy of Sciences Historical Papers',
        },
      ],
    };
  }

  if (isGarlicLemon) {
    return {
      summary: {
        plainEnglishRestatement:
          'The claim asserts that drinking a mixture of boiled garlic water and raw lemon juice every morning will permanently cure Type 2 diabetes and eradicate all viral pathogens within 48 hours without needing medical care.',
        centralFactualQuestion:
          'Does peer-reviewed clinical medicine or biochemical research indicate that garlic and lemon juice can eradicate diabetes mellitus and cure viral infections within 48 hours?',
        category: 'Health & Medical Science',
        safetyNotice,
      },
      evidenceChecklist: [
        {
          id: 'originator',
          question: 'Who originally made the claim?',
          status: 'unverified',
          statusText: 'Anonymous Viral Social Post',
          assessment: 'This claim circulates as an unattributed viral message across messaging apps and video platforms without clinical attribution.',
          guidance: 'Trace whether the protocol originated from an accredited medical research trial or an unverified viral chain message.',
        },
        {
          id: 'source_credibility',
          question: 'Is the source identifiable and credible?',
          status: 'lacking',
          statusText: 'No Medical Standing',
          assessment: 'The claim is not endorsed by the American Diabetes Association, World Health Organization, or any peer-reviewed endocrinology society.',
          guidance: 'Check if authors have clinical credentials in metabolism or infectious disease.',
        },
        {
          id: 'direct_evidence',
          question: 'Is there direct, verifiable evidence?',
          status: 'lacking',
          statusText: 'No Human Clinical Trials',
          assessment: 'While garlic (allicin) and lemon (vitamin C) contain dietary antioxidants, no randomized controlled clinical trials show complete reversal of diabetes or 48-hour viral eradication.',
          guidance: 'Look for double-blind, placebo-controlled human trials in accredited journals.',
        },
        {
          id: 'corroboration',
          question: 'Have independent reliable sources corroborated it?',
          status: 'lacking',
          statusText: 'Refuted by Medical Authorities',
          assessment: 'Medical researchers and fact-checking organizations have repeatedly noted that Type 2 diabetes requires multifaceted metabolic management, not simple herbal remedies.',
          guidance: 'Verify whether clinical guidelines from major hospital systems corroborate the recipe.',
        },
        {
          id: 'expert_consensus',
          question: 'Do relevant subject-matter experts agree?',
          status: 'lacking',
          statusText: 'Broad Expert Disagreement',
          assessment: 'Endocrinologists emphasize that beta-cell dysfunction and insulin resistance cannot be reversed in 48 hours by culinary ingredients.',
          guidance: 'Consult endocrine society guidelines on glycemic control.',
        },
        {
          id: 'data_accuracy',
          question: 'Are dates, locations, names, images, or statistics accurate?',
          status: 'lacking',
          statusText: 'No Empirical Data Provided',
          assessment: 'The claim provides no patient data, baseline HbA1c measurements, or biochemical viral titer measurements to substantiate its timeline.',
          guidance: 'Look for quantitative pre- and post-treatment laboratory blood panels.',
        },
        {
          id: 'simpler_explanations',
          question: 'Could simpler alternative explanations explain the evidence?',
          status: 'verified',
          statusText: 'Placebo Effect or Natural Viral Recovery',
          assessment: 'Many minor respiratory viruses resolve naturally over several days due to the immune system, leading individuals to mistakenly attribute their recovery to whatever home remedy they drank.',
          guidance: 'Check whether natural immune resolution explains perceived quick recovery.',
        },
        {
          id: 'falsifying_evidence',
          question: 'What evidence, if found, would weaken the claim?',
          status: 'verified',
          statusText: 'Persistent Elevated Blood Glucose',
          assessment: 'Routine continuous glucose monitoring demonstrating that blood sugar remains elevated after consuming garlic water directly refutes the cure claim.',
          guidance: 'Observe standard fasting plasma glucose and HbA1c tests.',
        },
        {
          id: 'strengthening_evidence',
          question: 'What evidence, if found, would strengthen the claim?',
          status: 'open',
          statusText: 'Published Phase III Clinical Trials',
          assessment: 'A peer-reviewed trial showing sustained normal fasting glucose without insulin in diabetic patients would be required to validate the claim.',
          guidance: 'Determine what clinical endpoints are required to demonstrate chronic illness remission.',
        },
      ],
      reasoningReview: {
        detectedPatterns: [
          {
            name: 'False Cause (Confusing Natural Recovery with Remedy Efficacy)',
            explanation: 'Because common viral infections resolve on their own in 2 to 7 days, people who drink garlic water often assume the beverage was responsible for their recovery.',
            constructiveAlternative: 'Distinguish between the body’s innate immune response and specific antiviral pharmacokinetics.',
          },
          {
            name: 'Overgeneralization',
            explanation: 'Taking general laboratory test-tube (in vitro) observations of allicin having antimicrobial properties and leaping to the conclusion that it cures systemic metabolic diseases in humans.',
            constructiveAlternative: 'Remember that what kills pathogens in a petri dish does not necessarily translate into an effective, targeted clinical treatment in the human body.',
          },
          {
            name: 'Appeal to Authority without Evidence (or Anti-Medical Tropes)',
            explanation: 'The claim implies that complex chronic diseases have effortless, concealed secret home cures that modern medicine overlooks.',
            constructiveAlternative: 'Recognize that effective therapies must be demonstrated through reproducible clinical measurements rather than romanticized natural panaceas.',
          },
        ],
        overallAssessment:
          'The claim conflates healthy dietary foods with pharmaceutical cures, overlooking the biological mechanisms of insulin regulation and viral replication.',
      },
      reliableSources: {
        summaryOverview:
          'Garlic and lemon are nutritious foods containing polyphenols and vitamin C, but clinical medicine confirms they cannot cure diabetes or eliminate systemic viruses in 48 hours.',
        wellSupportedFacts: [
          'Type 2 diabetes is a chronic metabolic disorder involving cellular insulin resistance and pancreatic beta-cell fatigue requiring dietary, lifestyle, and medical oversight.',
          'Consuming garlic and lemon is generally safe as part of a balanced diet, but does not substitute for insulin or prescribed hypoglycemic agents.',
          'Viruses replicate intracellularly; treating viral infections requires targeted antivirals or adaptive immune antibody responses.',
        ],
        uncertainOrDisputedPoints: [
          'Modest preliminary studies investigate whether long-term garlic supplementation may contribute to small improvements in lipid profiles and blood pressure, but effect sizes are modest.',
        ],
        claimsLackingCredibleEvidence: [
          'The claim that any beverage can cure Type 2 diabetes permanently in 48 hours has no biological or clinical plausibility.',
          'The assertion of total viral pathogen clearance in 48 hours is unfounded.',
        ],
      },
      betterQuestions: [
        {
          question: 'What biological mechanism determines insulin resistance in liver and muscle cells, and can a single food alter that genetic and metabolic pathway?',
          purpose: 'Grounds the inquiry in physiological endocrinology.',
        },
        {
          question: 'How do clinical trials measure HbA1c to assess diabetes management over 90-day intervals?',
          purpose: 'Clarifies why meaningful diabetes assessment requires months, not 48 hours.',
        },
        {
          question: 'What risks arise when patients with diabetes halt prescribed medications in favor of home remedies?',
          purpose: 'Highlights patient safety and potential complications like diabetic ketoacidosis.',
        },
        {
          question: 'How does the human immune system clear viral infections naturally, and how is this distinguished from a food cure?',
          purpose: 'Separates natural symptom resolution from post hoc reasoning.',
        },
        {
          question: 'Why do culinary compounds that show mild antimicrobial action in laboratory dishes often fail as clinical systemic antivirals?',
          purpose: 'Explains bioavailability, digestion, and systemic distribution limits.',
        },
      ],
      conclusion: {
        label: 'Not currently supported by credible evidence',
        explanation:
          'There is no scientific or clinical evidence supporting the claim that boiled garlic water and lemon juice can cure Type 2 diabetes or eliminate viral infections within 48 hours. While both ingredients are healthy culinary foods, diabetes is a complex metabolic disease that requires medical evaluation and evidence-based management. Halting prescription care in favor of unverified remedies poses serious medical risks.',
      },
      recommendedNextSteps: [
        {
          title: 'Consult Accredited Clinical Guidelines',
          action: 'Review evidence-based standards of care published by reputable diabetes associations regarding nutrition and glycemic control.',
          concreteTarget: 'American Diabetes Association (ADA) Clinical Practice Guidelines',
        },
        {
          title: 'Search Cochrane Systematic Reviews',
          action: 'Read Cochrane Library meta-analyses on garlic and dietary supplements for metabolic health.',
          concreteTarget: 'Cochrane Database of Systematic Reviews',
        },
        {
          title: 'Consult a Licensed Healthcare Provider',
          action: 'Discuss any proposed dietary changes with an endocrinologist or certified diabetes educator to ensure medications remain balanced.',
          concreteTarget: 'Primary Care Physician / Registered Dietitian',
        },
      ],
    };
  }

  // Default Generalized Empirical Analysis for any other claim
  const hasSecrecy = /secret|hide|hidden|they don't want you to know|conspiracy|coverup|suppressed/i.test(text);
  const hasCherryPick = /only look at|ignore|coincidence|proof is everywhere/i.test(text);
  const hasFalseCause = /after.*happened|caused by|connected to/i.test(text);
  const hasAuthority = /experts say|doctor said|insider|whistleblower/i.test(text);

  const detectedPatterns = [];
  if (hasSecrecy) {
    detectedPatterns.push({
      name: 'Appeal to Secrecy ("They Are Hiding It")',
      explanation: 'The narrative frames lack of official validation as evidence of deliberate institutional suppression, making the claim difficult to test through normal records.',
      constructiveAlternative: 'Distinguish between genuine documented institutional whistleblowing and unfalsifiable assumptions of universal coverups.',
    });
  }
  if (hasCherryPick) {
    detectedPatterns.push({
      name: 'Cherry-Picking Evidence',
      explanation: 'Highlighting select coincidences or anecdotal occurrences while discounting broader systemic statistical baselines.',
      constructiveAlternative: 'Look at representative datasets rather than curated individual examples.',
    });
  }
  if (hasFalseCause) {
    detectedPatterns.push({
      name: 'False Cause (Post Hoc Fallacy)',
      explanation: 'Assuming that because two events occurred in proximity, one necessarily caused the other without demonstrating a causal mechanism.',
      constructiveAlternative: 'Evaluate whether confounding variables, seasonal fluctuations, or chance correlations account for the observation.',
    });
  }
  if (hasAuthority) {
    detectedPatterns.push({
      name: 'Appeal to Authority without Clear Documentation',
      explanation: 'Invoking unnamed "experts," "whistleblowers," or credentials without providing verifiable names, papers, or testable data.',
      constructiveAlternative: 'Seek named specialists with identifiable domain publications subject to peer review.',
    });
  }

  return {
    summary: {
      plainEnglishRestatement: `The submitted statement asserts that: "${claimText.slice(0, 160)}${claimText.length > 160 ? '...' : ''}". It presents this occurrence as a verifiable factual event requiring examination.`,
      centralFactualQuestion: 'What verifiable, independent documentation exists to substantiate the core factual assertions in this claim?',
      category: 'General Public Claim',
      safetyNotice,
    },
    evidenceChecklist: [
      {
        id: 'originator',
        question: 'Who originally made the claim?',
        status: 'open',
        statusText: 'Origin Unverified',
        assessment: 'The specific primary author, timestamp, or original publication source requires clear attribution to separate first-hand witnessing from secondary retelling.',
        guidance: 'Find the earliest known instance of the claim to verify if it stems from a reliable witness or anonymous internet post.',
      },
      {
        id: 'source_credibility',
        question: 'Is the source identifiable and credible?',
        status: 'open',
        statusText: 'Source Evaluation Needed',
        assessment: 'Evaluating this requires verifying whether the disseminating source has transparent editorial standards, recognized subject-matter expertise, and no obvious financial conflict.',
        guidance: 'Check the publisher’s correction policy and domain background.',
      },
      {
        id: 'direct_evidence',
        question: 'Is there direct, verifiable evidence?',
        status: 'lacking',
        statusText: 'Awaiting Primary Proof',
        assessment: 'At present, direct physical, documentary, or official institutional evidence directly supporting the central assertion has not been demonstrated.',
        guidance: 'Distinguish between assertive rhetoric and tangible, inspectable primary records.',
      },
      {
        id: 'corroboration',
        question: 'Have independent reliable sources corroborated it?',
        status: 'lacking',
        statusText: 'No Independent Corroboration',
        assessment: 'Multiple independent, competitive journalistic or scientific organizations have not verified the core assertions independently.',
        guidance: 'Check whether multiple reputable news agencies or research institutes confirm the story.',
      },
      {
        id: 'expert_consensus',
        question: 'Do relevant subject-matter experts agree?',
        status: 'open',
        statusText: 'Expert Consensus Lacking',
        assessment: 'Relevant specialists in this field have either contested the claim or indicated that insufficient reliable evidence exists to substantiate it.',
        guidance: 'Review peer-reviewed literature or consensus statements from professional associations.',
      },
      {
        id: 'data_accuracy',
        question: 'Are dates, locations, names, images, or statistics accurate?',
        status: 'mixed',
        statusText: 'Needs Detail Verification',
        assessment: 'Claims often incorporate real place names or authentic background dates alongside unverified conclusions, requiring granular fact verification.',
        guidance: 'Run reverse-image searches and cross-check named individuals and dates against primary archives.',
      },
      {
        id: 'simpler_explanations',
        question: 'Could simpler alternative explanations explain the evidence?',
        status: 'verified',
        statusText: 'Simpler Explanations Exist',
        assessment: 'Standard explanations—such as coincidence, misinterpretation of context, or exaggeration—typically account for the observations without requiring complex unproven assumptions.',
        guidance: 'Consider whether everyday psychological or operational factors explain the phenomena.',
      },
      {
        id: 'falsifying_evidence',
        question: 'What evidence, if found, would weaken the claim?',
        status: 'verified',
        statusText: 'Falsifiability Criteria Identified',
        assessment: 'The claim would be substantially weakened if official logs, public data repositories, or contemporaneous documentation directly contradict the timeline or participants named.',
        guidance: 'Identify clear empirical observations that would show the claim to be false.',
      },
      {
        id: 'strengthening_evidence',
        question: 'What evidence, if found, would strengthen the claim?',
        status: 'open',
        statusText: 'Substantiation Requirements',
        assessment: 'The claim would be strengthened by authenticated primary documents, high-fidelity unedited footage verified by forensic specialists, or corroborated witness testimony under oath.',
        guidance: 'Define the minimum standard of proof necessary for rational acceptance.',
      },
    ],
    reasoningReview: {
      detectedPatterns: detectedPatterns.length > 0 ? detectedPatterns : [
        {
          name: 'Unfalsifiable Framework',
          explanation: 'The claim is phrased in a way where counter-evidence might be dismissed as unconvincing, making rigorous testing challenging.',
          constructiveAlternative: 'Determine in advance what specific evidence would be accepted as proving or disproving the premise.',
        },
      ],
      overallAssessment:
        'The statement combines assertive conclusions with limited immediate primary evidence, suggesting that careful verification of original sources is essential before drawing firm conclusions.',
    },
    reliableSources: {
      summaryOverview:
        'Standard evidentiary sources and reference archives currently do not provide corroborating documentation for this specific claim as presented.',
      wellSupportedFacts: [
        'The topic touches upon subjects of legitimate public curiosity, but verified baseline facts must be distinguished from speculative commentary.',
        'Documented historical and scientific records require rigorous chain of custody and independent peer verification.',
      ],
      uncertainOrDisputedPoints: [
        'Specific details regarding the origin, timing, and motives of the claim remain unverified in the public record.',
      ],
      claimsLackingCredibleEvidence: [
        'The central claim lacks direct documentary, physical, or peer-reviewed corroboration in reputable repositories.',
      ],
    },
    betterQuestions: [
      {
        question: 'Where was this claim first documented, and who was the original first-hand observer?',
        purpose: 'Establishes provenance and separates primary evidence from rumors.',
      },
      {
        question: 'What would an impartial subject-matter expert with access to raw data say about this explanation?',
        purpose: 'Brings domain expertise to bear on potential technical nuances.',
      },
      {
        question: 'Are there financial, political, or social incentives driving the promotion of this specific story?',
        purpose: 'Examines potential motivations or commercial monetization of viral content.',
      },
      {
        question: 'What verifiable records (e.g. court filings, public ledgers, satellite imagery) should exist if this claim is accurate?',
        purpose: 'Focuses on tangible documentation that would inevitably be produced.',
      },
      {
        question: 'Could ordinary human cognitive biases, such as pattern recognition in random noise, explain why this story feels compelling?',
        purpose: 'Encourages gentle self-reflection and intellectual humility.',
      },
    ],
    conclusion: {
      label: 'Not currently supported by credible evidence',
      explanation:
        'Based on current verifiable records, this claim lacks direct, reliable supporting evidence. Independent corroboration from credible primary sources or domain experts has not been established. While open-minded inquiry is valuable, critical thinkers should withhold belief until verifiable proof emerges.',
    },
    recommendedNextSteps: [
      {
        title: 'Check Primary Records and Repositories',
        action: 'Search public archives, government databases, or academic search engines for original documentation rather than social media commentary.',
        concreteTarget: 'Primary Historical Archives & Public Records Repositories',
      },
      {
        title: 'Consult Independent Fact-Checking Organizations',
        action: 'Review analyses by non-partisan verification organizations adhering to the International Fact-Checking Network (IFCN) code of principles.',
        concreteTarget: 'IFCN Signatories (e.g. PolitiFact, FactCheck.org, Snopes, AP Fact Check)',
      },
      {
        title: 'Seek Domain-Specific Academic Literature',
        action: 'Examine peer-reviewed research papers and consensus reviews in the relevant discipline.',
        concreteTarget: 'Google Scholar / PubMed / Academic Library Databases',
      },
    ],
  };
}
