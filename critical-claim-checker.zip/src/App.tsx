import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { DisclaimerBanner } from './components/DisclaimerBanner';
import { ClaimInputSection } from './components/ClaimInputSection';
import { PlainEnglishSummarySection } from './components/PlainEnglishSummarySection';
import { EvidenceChecklistSection } from './components/EvidenceChecklistSection';
import { ReasoningReviewSection } from './components/ReasoningReviewSection';
import { ReliableSourcesSection } from './components/ReliableSourcesSection';
import { BetterQuestionsSection } from './components/BetterQuestionsSection';
import { ConclusionSection } from './components/ConclusionSection';
import { NextStepsSection } from './components/NextStepsSection';
import { SavedReportsModal } from './components/SavedReportsModal';
import { MethodologyModal } from './components/MethodologyModal';
import { ClaimAnalysis, ChecklistItem } from './types';
import {
  Printer,
  Copy,
  Check,
  Bookmark,
  BookmarkCheck,
  RotateCcw,
  AlertCircle,
  HelpCircle,
} from 'lucide-react';

const STORAGE_KEY = 'critical_claim_checker_saved_reports_v1';

export default function App() {
  const [claimText, setClaimText] = useState<string>('');
  const [currentAnalysis, setCurrentAnalysis] = useState<ClaimAnalysis | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);
  const [savedReports, setSavedReports] = useState<ClaimAnalysis[]>([]);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isMethodologyOpen, setIsMethodologyOpen] = useState<boolean>(false);
  const [methodologyTab, setMethodologyTab] = useState<'framework' | 'reasoning'>('framework');
  const [copiedReport, setCopiedReport] = useState<boolean>(false);

  // Load saved notebook from localStorage on mount
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed)) {
          setSavedReports(parsed);
        }
      }
    } catch (err) {
      console.error('Failed to load saved reports:', err);
    }
  }, []);

  // Save notebook to localStorage
  const persistSavedReports = (reports: ClaimAnalysis[]) => {
    setSavedReports(reports);
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(reports));
    } catch (err) {
      console.error('Failed to save reports to localStorage:', err);
    }
  };

  const handleAnalyzeClaim = async () => {
    if (!claimText.trim()) return;

    setIsLoading(true);
    setError(null);

    try {
      const res = await fetch('/api/analyze-claim', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ claim: claimText.trim() }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || 'Failed to complete analysis');
      }

      setCurrentAnalysis(data);

      // Smooth scroll to analysis
      setTimeout(() => {
        document.getElementById('analysis-report')?.scrollIntoView({ behavior: 'smooth' });
      }, 150);
    } catch (err: any) {
      console.error('Analysis error:', err);
      setError(
        err.message ||
          'Unable to reach analysis service. Please verify your connection or check API credentials.'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewAnalysis = () => {
    setClaimText('');
    setCurrentAnalysis(null);
    setError(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenMethodology = (tab: 'framework' | 'reasoning' = 'framework') => {
    setMethodologyTab(tab);
    setIsMethodologyOpen(true);
  };

  const handleUpdateItemUserStatus = (
    id: string,
    status: 'checked' | 'questionable' | 'unresolved'
  ) => {
    if (!currentAnalysis) return;
    const updatedChecklist = currentAnalysis.evidenceChecklist.map((item) =>
      item.id === id ? { ...item, userStatus: status } : item
    );
    const updatedAnalysis = { ...currentAnalysis, evidenceChecklist: updatedChecklist };
    setCurrentAnalysis(updatedAnalysis);

    // If currently saved in notebook, update there too
    const exists = savedReports.some((r) => r.id === updatedAnalysis.id);
    if (exists) {
      const newSaved = savedReports.map((r) =>
        r.id === updatedAnalysis.id ? updatedAnalysis : r
      );
      persistSavedReports(newSaved);
    }
  };

  const handleUpdateItemNotes = (id: string, notes: string) => {
    if (!currentAnalysis) return;
    const updatedChecklist = currentAnalysis.evidenceChecklist.map((item) =>
      item.id === id ? { ...item, userNotes: notes } : item
    );
    const updatedAnalysis = { ...currentAnalysis, evidenceChecklist: updatedChecklist };
    setCurrentAnalysis(updatedAnalysis);

    // If currently saved in notebook, update there too
    const exists = savedReports.some((r) => r.id === updatedAnalysis.id);
    if (exists) {
      const newSaved = savedReports.map((r) =>
        r.id === updatedAnalysis.id ? updatedAnalysis : r
      );
      persistSavedReports(newSaved);
    }
  };

  const isSavedInNotebook = currentAnalysis
    ? savedReports.some((r) => r.id === currentAnalysis.id)
    : false;

  const handleToggleSaveReport = () => {
    if (!currentAnalysis) return;

    if (isSavedInNotebook) {
      const filtered = savedReports.filter((r) => r.id !== currentAnalysis.id);
      persistSavedReports(filtered);
    } else {
      const updated = [currentAnalysis, ...savedReports.filter((r) => r.id !== currentAnalysis.id)];
      persistSavedReports(updated);
    }
  };

  const handleDeleteReport = (id: string) => {
    const filtered = savedReports.filter((r) => r.id !== id);
    persistSavedReports(filtered);
  };

  const handleClearAllSaved = () => {
    if (window.confirm('Clear all saved claim reports from this device?')) {
      persistSavedReports([]);
    }
  };

  const handleCopyFullReport = () => {
    if (!currentAnalysis) return;

    const sections = [
      `CRITICAL CLAIM CHECKER — ANALYSIS REPORT`,
      `Submitted Claim: "${currentAnalysis.originalClaim}"`,
      `Analyzed: ${new Date(currentAnalysis.analyzedAt).toLocaleString()}`,
      `\n------------------------------------------------------------`,
      `1. PLAIN-ENGLISH SUMMARY:`,
      currentAnalysis.summary.plainEnglishRestatement,
      `Central Factual Question: ${currentAnalysis.summary.centralFactualQuestion}`,
      `\n------------------------------------------------------------`,
      `2. EVIDENCE CHECKLIST:`,
      currentAnalysis.evidenceChecklist
        .map(
          (item, i) =>
            `${i + 1}. ${item.question} [Status: ${item.statusText}]\n   Assessment: ${item.assessment}` +
            (item.userNotes ? `\n   Personal Notes: "${item.userNotes}"` : '')
        )
        .join('\n\n'),
      `\n------------------------------------------------------------`,
      `3. REASONING REVIEW:`,
      currentAnalysis.reasoningReview.overallAssessment,
      currentAnalysis.reasoningReview.detectedPatterns.length > 0
        ? currentAnalysis.reasoningReview.detectedPatterns
            .map(
              (p) =>
                `• ${p.name}: ${p.explanation}\n  Constructive note: ${p.constructiveAlternative}`
            )
            .join('\n\n')
        : 'No standard cognitive pitfalls identified in the claim text.',
      `\n------------------------------------------------------------`,
      `4. WHAT RELIABLE SOURCES INDICATE:`,
      `Consensus Overview: ${currentAnalysis.reliableSources.summaryOverview}`,
      `\nWell-Supported Facts:\n` +
        currentAnalysis.reliableSources.wellSupportedFacts.map((f) => `• ${f}`).join('\n'),
      `\nUncertain or Disputed Points:\n` +
        currentAnalysis.reliableSources.uncertainOrDisputedPoints.map((p) => `• ${p}`).join('\n'),
      `\nClaims Lacking Credible Supporting Evidence:\n` +
        currentAnalysis.reliableSources.claimsLackingCredibleEvidence
          .map((c) => `• ${c}`)
          .join('\n'),
      `\n------------------------------------------------------------`,
      `5. BETTER QUESTIONS TO ASK:`,
      currentAnalysis.betterQuestions
        .map((q, i) => `${i + 1}. ${q.question} (Purpose: ${q.purpose})`)
        .join('\n'),
      `\n------------------------------------------------------------`,
      `6. BALANCED CONCLUSION:`,
      `Evaluation: "${currentAnalysis.conclusion.label}"`,
      currentAnalysis.conclusion.explanation,
      `\n------------------------------------------------------------`,
      `7. RECOMMENDED NEXT STEPS:`,
      currentAnalysis.recommendedNextSteps
        .map((s, i) => `${i + 1}. ${s.title}: ${s.action} (${s.concreteTarget})`)
        .join('\n'),
      `\nDisclaimer: This tool supports critical thinking. It does not replace expert advice, official investigations, or primary-source verification.`,
    ].join('\n');

    navigator.clipboard.writeText(sections);
    setCopiedReport(true);
    setTimeout(() => setCopiedReport(false), 2500);
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="min-h-screen bg-[#fbf9f5] flex flex-col text-stone-900">
      <Header
        onNewAnalysis={handleNewAnalysis}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenMethodology={handleOpenMethodology}
        savedCount={savedReports.length}
      />

      <main className="flex-1 max-w-5xl w-full mx-auto px-4 sm:px-6 py-8 sm:py-12 space-y-10">
        {/* Core Disclaimer */}
        <DisclaimerBanner urgentNotice={currentAnalysis?.summary?.safetyNotice} />

        {/* Input Card */}
        <ClaimInputSection
          claimText={claimText}
          setClaimText={setClaimText}
          onAnalyze={handleAnalyzeClaim}
          isLoading={isLoading}
        />

        {/* Error Notification */}
        {error && (
          <div className="border border-red-300 bg-red-50/90 rounded-xl p-5 text-red-900 flex items-start gap-3.5">
            <AlertCircle className="w-5 h-5 text-red-700 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="font-semibold text-sm">Unable to analyze claim</h3>
              <p className="text-xs sm:text-sm font-serif-body">{error}</p>
            </div>
          </div>
        )}

        {/* Analysis Output Section (All 7 required sections) */}
        {currentAnalysis && (
          <div id="analysis-report" className="space-y-8 pt-4">
            {/* Report Actions Toolbar */}
            <div className="no-print bg-white border border-stone-200/90 rounded-lg p-3 sm:p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-3 shadow-2xs">
              <div className="flex items-center gap-2 text-xs font-mono text-stone-500">
                <span className="font-semibold text-stone-800">Report Generated:</span>
                <span>{new Date(currentAnalysis.analyzedAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                <span className="text-stone-300">·</span>
                <span className="text-stone-700 font-medium">{currentAnalysis.conclusion?.label}</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleToggleSaveReport}
                  className={`px-3 py-1.5 text-xs font-medium rounded-md border transition-colors flex items-center gap-1.5 cursor-pointer ${
                    isSavedInNotebook
                      ? 'bg-stone-900 text-white border-stone-900'
                      : 'bg-white hover:bg-stone-50 border-stone-200 text-stone-700'
                  }`}
                >
                  {isSavedInNotebook ? (
                    <>
                      <BookmarkCheck className="w-3.5 h-3.5" />
                      <span>Saved in Notebook</span>
                    </>
                  ) : (
                    <>
                      <Bookmark className="w-3.5 h-3.5 text-stone-400" />
                      <span>Save to Notebook</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handleCopyFullReport}
                  className="px-3 py-1.5 text-xs font-medium rounded-md border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  {copiedReport ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span>Copied Report</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-stone-400" />
                      <span>Copy Full Text</span>
                    </>
                  )}
                </button>

                <button
                  type="button"
                  onClick={handlePrint}
                  className="px-3 py-1.5 text-xs font-medium rounded-md border border-stone-200 bg-white hover:bg-stone-50 text-stone-700 transition-colors flex items-center gap-1.5 cursor-pointer"
                >
                  <Printer className="w-3.5 h-3.5 text-stone-400" />
                  <span>Print</span>
                </button>
              </div>
            </div>

            {/* Section 1: Plain-English summary */}
            <div className="print-break-inside-avoid">
              <PlainEnglishSummarySection
                summary={currentAnalysis.summary}
                originalClaim={currentAnalysis.originalClaim}
              />
            </div>

            {/* Section 2: Evidence checklist */}
            <div className="print-break-inside-avoid">
              <EvidenceChecklistSection
                items={currentAnalysis.evidenceChecklist}
                onUpdateItemUserStatus={handleUpdateItemUserStatus}
                onUpdateItemNotes={handleUpdateItemNotes}
              />
            </div>

            {/* Section 3: Reasoning review */}
            <div className="print-break-inside-avoid">
              <ReasoningReviewSection
                patterns={currentAnalysis.reasoningReview.detectedPatterns}
                overallAssessment={currentAnalysis.reasoningReview.overallAssessment}
              />
            </div>

            {/* Section 4: What reliable sources indicate */}
            <div className="print-break-inside-avoid">
              <ReliableSourcesSection sources={currentAnalysis.reliableSources} />
            </div>

            {/* Section 5: Better questions to ask */}
            <div className="print-break-inside-avoid">
              <BetterQuestionsSection questions={currentAnalysis.betterQuestions} />
            </div>

            {/* Section 6: Balanced conclusion */}
            <div className="print-break-inside-avoid">
              <ConclusionSection conclusion={currentAnalysis.conclusion} />
            </div>

            {/* Section 7: Recommended next steps */}
            <div className="print-break-inside-avoid">
              <NextStepsSection steps={currentAnalysis.recommendedNextSteps} />
            </div>

            {/* Re-analyze or reset */}
            <div className="no-print pt-6 pb-12 flex justify-center">
              <button
                type="button"
                onClick={handleNewAnalysis}
                className="inline-flex items-center gap-2 px-5 py-2.5 text-xs sm:text-sm font-semibold rounded-lg bg-stone-900 hover:bg-stone-800 text-white shadow-xs transition-colors cursor-pointer"
              >
                <RotateCcw className="w-4 h-4" />
                <span>Examine Another Claim</span>
              </button>
            </div>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200 bg-stone-100/60 py-8 text-xs text-stone-500 no-print">
        <div className="max-w-5xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-center sm:text-left">
          <div className="space-y-1">
            <span className="font-serif-display font-semibold text-stone-800 text-sm">
              Critical Claim Checker
            </span>
            <p className="font-serif-body text-stone-600">
              Supporting intellectual humility, evidence-based inquiry, and careful reasoning.
            </p>
          </div>
          <div className="text-stone-400 font-mono text-[11px]">
            WCAG AA Legibility · No telemetry · Private local notebook
          </div>
        </div>
      </footer>

      {/* Saved Reports Drawer / Modal */}
      <SavedReportsModal
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        savedReports={savedReports}
        onSelectReport={(report) => {
          setCurrentAnalysis(report);
          setClaimText(report.originalClaim);
          setTimeout(() => {
            document.getElementById('analysis-report')?.scrollIntoView({ behavior: 'smooth' });
          }, 100);
        }}
        onDeleteReport={handleDeleteReport}
        onClearAll={handleClearAllSaved}
      />

      {/* Methodology & Guide Modal */}
      <MethodologyModal
        isOpen={isMethodologyOpen}
        onClose={() => setIsMethodologyOpen(false)}
        initialTab={methodologyTab}
      />
    </div>
  );
}
