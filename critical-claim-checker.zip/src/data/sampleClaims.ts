export interface SampleClaim {
  id: string;
  category: string;
  title: string;
  claimText: string;
  contextNote: string;
}

export const SAMPLE_CLAIMS: SampleClaim[] = [
  {
    id: 'moon-landing',
    category: 'History & Space',
    title: 'Apollo Moon Landing Staging',
    claimText: 'The Apollo 11 moon landing in 1969 was never real; it was secretly staged on a Hollywood soundstage directed by Stanley Kubrick because the United States was falling behind the Soviet Union in the space race and needed a propaganda victory.',
    contextNote: 'A classic historical claim with extensive physical, telemetry, and international evidence available.',
  },
  {
    id: 'health-garlic',
    category: 'Health & Wellness',
    title: 'Garlic Water & Lemon Cure',
    claimText: 'Drinking freshly boiled garlic water mixed with raw lemon juice on an empty stomach every morning cures Type 2 diabetes permanently and flushes out all viral pathogens within 48 hours without needing prescription medications.',
    contextNote: 'A viral health recipe claiming rapid reversal of chronic illness and complete antiviral protection.',
  },
  {
    id: 'bermuda-triangle',
    category: 'Geography & Legend',
    title: 'Bermuda Triangle Disappearances',
    claimText: 'More commercial ships and airplanes vanish without a trace in the Bermuda Triangle than in any other equivalent ocean region on Earth, caused by magnetic field anomalies and submerged ancient structures.',
    contextNote: 'An enduring popular maritime mystery frequently tested against Lloyd’s of London maritime records.',
  },
  {
    id: 'subliminal-advertising',
    category: 'Media & Psychology',
    title: 'Subliminal Movie Theater Commands',
    claimText: 'Flashing single-frame invisible messages like "Eat Popcorn" and "Drink Coca-Cola" during movie screenings involuntarily forces audiences to buy concession snacks, which is why theaters keep it confidential.',
    contextNote: 'A widely believed claim originating from James Vicary’s 1957 market experiment that he later confessed was fabricated.',
  },
];
