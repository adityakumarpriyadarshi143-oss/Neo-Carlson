export type ConclusionLabel =
  | 'Well supported'
  | 'Partly supported, important gaps remain'
  | 'Not currently supported by credible evidence'
  | 'Insufficient information to judge';

export type ChecklistStatus = 'verified' | 'mixed' | 'unverified' | 'lacking' | 'open';

export interface ChecklistItem {
  id: string;
  question: string;
  status: ChecklistStatus;
  statusText: string;
  assessment: string;
  guidance: string;
  userStatus?: 'checked' | 'questionable' | 'unresolved' | 'pending';
  userNotes?: string;
}

export interface ReasoningIssue {
  name: string;
  explanation: string;
  constructiveAlternative: string;
}

export interface BetterQuestion {
  question: string;
  purpose: string;
}

export interface VerificationStep {
  title: string;
  action: string;
  concreteTarget: string;
}

export interface ClaimAnalysis {
  id: string;
  originalClaim: string;
  analyzedAt: string;
  summary: {
    plainEnglishRestatement: string;
    centralFactualQuestion: string;
    category?: string;
    safetyNotice?: string | null;
  };
  evidenceChecklist: ChecklistItem[];
  reasoningReview: {
    detectedPatterns: ReasoningIssue[];
    overallAssessment: string;
  };
  reliableSources: {
    wellSupportedFacts: string[];
    uncertainOrDisputedPoints: string[];
    claimsLackingCredibleEvidence: string[];
    summaryOverview: string;
  };
  betterQuestions: BetterQuestion[];
  conclusion: {
    label: ConclusionLabel;
    explanation: string;
  };
  recommendedNextSteps: VerificationStep[];
}
